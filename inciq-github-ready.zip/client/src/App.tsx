import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import ReportIncident from "./pages/ReportIncident";
import OperatorDashboard from "./pages/OperatorDashboard";
import IncidentsMap from "./pages/IncidentsMap";
import Statistics from "./pages/Statistics";
import INCIQApp from "./pages/INCIQApp";
import NotificationCenter from "./pages/NotificationCenter";
import IncidentTracking from "./pages/IncidentTracking";
import FeedbackSystem from "./pages/FeedbackSystem";
import Routing from "./pages/Routing";
import Report from "./pages/Report";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/report" component={ReportIncident} />
      <Route path="/dashboard" component={OperatorDashboard} />
      <Route path="/map" component={IncidentsMap} />
      <Route path="/statistics" component={Statistics} />
      <Route path="/inciq" component={INCIQApp} />
      <Route path="/notifications" component={NotificationCenter} />
      <Route path="/tracking" component={IncidentTracking} />
      <Route path="/feedback" component={FeedbackSystem} />
      <Route path="/routing" component={Routing} />
      <Route path="/smart-report" component={Report} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
