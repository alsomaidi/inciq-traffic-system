import { useState, useEffect } from "react";
import { useSearchParams } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertCircle,
  Download,
  Printer,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  Wrench,
  Clock,
  MapPin,
  User,
  Phone,
  FileText,
  Map,
  Loader,
  Send,
  CheckCheck,
  Users,
  Navigation,
  Activity,
  Zap,
  Shield,
} from "lucide-react";
import { toast } from "sonner";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { trpc } from "@/lib/trpc";

interface RepairItem {
  id: string;
  title: string;
  severity: "low" | "medium" | "high";
  description: string;
  estimatedCost: number;
  estimatedTime: string;
}

interface Party {
  id: number;
  partyName: string;
  phone?: string | null;
  faultPercentage?: number | null;
  vehicleType?: string | null;
  insuranceCompany?: string | null;
  healthStatus?: string | null;
  idNumber?: string | null;
  vehicleNumber?: string | null;
  incidentId?: number;
  createdAt?: Date;
}

export default function Report() {
  const [searchParams] = useSearchParams();
  const incidentId = parseInt((searchParams as any).id || "0");
  const [errorRate, setErrorRate] = useState(65);
  const [isSending, setIsSending] = useState(false);

  // جلب بيانات الحادث من قاعدة البيانات
  const { data: fullDetails, isLoading, error } = trpc.incidents.getFullDetails.useQuery(
    { id: incidentId },
    { enabled: incidentId > 0 }
  );

  // جلب حالة الإرسالات
  const { data: reportSends } = trpc.reports.getStatus.useQuery(
    { incidentId },
    { enabled: incidentId > 0 }
  );

  // إرسال التقرير
  const sendReportMutation = trpc.reports.send.useMutation();

  const incident = fullDetails?.incident;
  const services = fullDetails?.services || [];
  const parties = fullDetails?.parties || [];

  // حساب نسبة الخطأ بناءً على الأطراف المتورطة
  useEffect(() => {
    if (parties.length > 0) {
      const avgFault = parties.reduce((sum, p) => sum + (p.faultPercentage || 0), 0) / parties.length;
      setErrorRate(Math.round(avgFault));
    }
  }, [parties]);

  // ورقة الإصلاح الموحدة
  const repairItem: RepairItem = {
    id: "1",
    title: "تقييم الأضرار والإصلاحات المطلوبة",
    severity: "high",
    description: "سيتم تقدير الأضرار والتكاليف من قبل شركة التأمين بناءً على الفحص الشامل للمركبة",
    estimatedCost: 0,
    estimatedTime: "متروك لتقدير شركة التأمين",
  };

  const accuracy = 100 - errorRate;

  const handleDownloadPDF = async () => {
    try {
      const element = document.getElementById("report-content");
      if (!element) {
        toast.error("لم يتم العثور على محتوى التقرير");
        return;
      }

      const canvas = await html2canvas(element, {
        backgroundColor: "#1a1a2e",
        scale: 2,
      });

      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      });

      const imgData = canvas.toDataURL("image/png");
      const imgWidth = 210;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
      pdf.save(`incident-report-${incident?.id || "unknown"}.pdf`);

      toast.success("تم تحميل التقرير بنجاح");
    } catch (error) {
      console.error("Error generating PDF:", error);
      toast.error("حدث خطأ أثناء تحميل التقرير");
    }
  };

  const handlePrint = () => {
    window.print();
    toast.success("تم فتح نافذة الطباعة");
  };

  const handleOpenMap = () => {
    if (incident) {
      const lat = typeof incident.latitude === "string" ? incident.latitude : String(incident.latitude);
      const lng = typeof incident.longitude === "string" ? incident.longitude : String(incident.longitude);
      const mapUrl = `https://www.google.com/maps?q=${lat},${lng}`;
      window.open(mapUrl, "_blank");
      toast.success("تم فتح الخريطة");
    }
  };

  const handleSendReport = async () => {
    if (!incident) {
      toast.error("لم يتم العثور على بيانات الحادث");
      return;
    }

    setIsSending(true);
    try {
      // إعداد قائمة المستقبلين
      const recipients = [];

      // إضافة الطرفين المتورطين
      parties.forEach((party) => {
        if (party.phone) {
          recipients.push({
            type: "party" as const,
            email: `party${party.id}@example.com`,
            phone: party.phone,
            name: party.partyName,
          });
        }
      });

      // إضافة شركة نجم
      recipients.push({
        type: "najm" as const,
        email: "reports@najm.com.sa",
        phone: "+966112222222",
        name: "شركة نجم",
      });

      // إضافة شركة التأمين (مثال)
      recipients.push({
        type: "insurance" as const,
        email: "claims@insurance.com.sa",
        phone: "+966112222222",
        name: "شركة التأمين",
      });

      // إرسال التقرير
      await sendReportMutation.mutateAsync({
        incidentId,
        recipients,
      });

      toast.success("تم إرسال التقرير بنجاح للطرفين وشركة نجم والتأمين");
    } catch (error) {
      console.error("Error sending report:", error);
      toast.error("حدث خطأ أثناء إرسال التقرير");
    } finally {
      setIsSending(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Loader className="w-12 h-12 text-cyan-500 animate-spin mx-auto mb-4" />
          <p className="text-gray-400">جاري تحميل التقرير...</p>
        </div>
      </div>
    );
  }

  // استخدام بيانات وهمية كبديل إذا لم يتم العثور على الحادث
  const displayIncident = incident || {
    id: incidentId,
    incidentType: "breakdown" as const,
    location: "طريق الملك فهد - الرياض",
    latitude: "24.7136",
    longitude: "46.6753",
    description: "تعطل سيارة على الطريق",
    severity: "medium" as const,
    status: "pending" as const,
    reporterId: 0,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  if (error && !incident) {
    console.warn("Failed to load incident data:", error);
  }

  // البيانات المحاكاة للأطراف
  const displayParties: Party[] = parties.length > 0 ? parties : [
    {
      id: 1,
      partyName: "السائق الأول",
      idNumber: "1234567890",
      vehicleType: "خصوصي",
      phone: "0501234567",
      insuranceCompany: "شركة التأمين الأهلية",
      healthStatus: "سليم",
      faultPercentage: 70,
    },
    {
      id: 2,
      partyName: "السائق الثاني",
      idNumber: "0987654321",
      vehicleType: "نقل",
      phone: "0509876543",
      insuranceCompany: "شركة التأمين الراجحي",
      healthStatus: "سليم",
      faultPercentage: 30,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
            <FileText className="w-10 h-10 text-cyan-500" />
            🟦 INCIQ – Incident Intelligence
          </h1>
          <p className="text-gray-400">تقرير الحادث الذكي (Automated Incident Report)</p>
        </div>

        <div id="report-content" className="space-y-6">
          {/* 1. Basic Info & Report Number */}
          <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div>
                <p className="text-gray-400 text-sm mb-2">رقم التقرير</p>
                <p className="text-2xl font-bold text-cyan-500">INCIQ-2025-{String(displayIncident.id).padStart(4, '0')}</p>
              </div>
              <div>
                <p className="text-gray-400 text-sm mb-2">تاريخ الإصدار</p>
                <p className="text-white">{new Date().toLocaleDateString("ar-SA")}</p>
              </div>
              <div>
                <p className="text-gray-400 text-sm mb-2">وقت الحادث</p>
                <p className="text-white">{new Date(displayIncident.createdAt).toLocaleTimeString("ar-SA")}</p>
              </div>
              <div>
                <p className="text-gray-400 text-sm mb-2">الموقع</p>
                <p className="text-white flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-cyan-500" />
                  {displayIncident.location}
                </p>
              </div>
            </div>
          </Card>

          {/* 2. Parties Information */}
          <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <Users className="w-6 h-6 text-cyan-500" />
              بيانات الأطراف المشاركة
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="text-right py-3 px-4 text-gray-400">السائق</th>
                    <th className="text-right py-3 px-4 text-gray-400">رقم الهوية</th>
                    <th className="text-right py-3 px-4 text-gray-400">نوع المركبة</th>
                    <th className="text-right py-3 px-4 text-gray-400">التأمين</th>
                    <th className="text-right py-3 px-4 text-gray-400">الحالة الصحية</th>
                  </tr>
                </thead>
                <tbody>
                  {displayParties.map((party) => (
                    <tr key={party.id} className="border-b border-white/5 hover:bg-white/5">
                      <td className="py-3 px-4 text-white">{party.partyName}</td>
                      <td className="py-3 px-4 text-gray-300">{party.idNumber || "غير متوفر"}</td>
                      <td className="py-3 px-4 text-gray-300">{party.vehicleType || "غير متوفر"}</td>
                      <td className="py-3 px-4 text-gray-300">{party.insuranceCompany || "غير متوفر"}</td>
                      <td className="py-3 px-4">
                        <Badge className="bg-green-500/20 text-green-300">{party.healthStatus || "سليم"}</Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {/* 3. Incident Description */}
          <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <AlertCircle className="w-6 h-6 text-yellow-500" />
              وصف الحادث التلقائي (Generated Incident Summary)
            </h3>
            <p className="text-gray-300 mb-4">
              اعتمادًا على تحليل الذكاء الاصطناعي لبث الكاميرات والأقمار الصناعية وبيانات الطريق:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">نوع الحادث</p>
                <p className="text-white font-semibold">
                  {displayIncident.incidentType === "injury"
                    ? "إصابات"
                    : displayIncident.incidentType === "breakdown"
                    ? "تعطل سيارة"
                    : "حادث مروري / اصطدام"}
                </p>
              </div>
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">السرعات المقدّرة</p>
                <p className="text-white font-semibold">الطرف الأول: 60 كم/س | الطرف الثاني: 45 كم/س</p>
              </div>
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">زاوية الاصطدام</p>
                <p className="text-white font-semibold">45°</p>
              </div>
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">نقطة فقدان السيطرة</p>
                <p className="text-white font-semibold">15 متر قبل موقع التصادم</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm mt-4 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              {displayIncident.description}
            </p>
          </Card>

          {/* 4. Scene Reconstruction */}
          <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <Navigation className="w-6 h-6 text-purple-500" />
              إعادة بناء المشهد (AI Reconstruction)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 p-4 rounded-lg border border-purple-500/20">
                <p className="text-gray-400 text-sm mb-2">تحليل آخر 5 دقائق قبل الحادث</p>
                <p className="text-white">تم تحليل حركة المركبات والسرعات والمسافات</p>
              </div>
              <div className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 p-4 rounded-lg border border-purple-500/20">
                <p className="text-gray-400 text-sm mb-2">مسارات المركبات (Trajectory)</p>
                <p className="text-white">تم تتبع مسار كل مركبة قبل وأثناء وبعد التصادم</p>
              </div>
              <div className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 p-4 rounded-lg border border-purple-500/20">
                <p className="text-gray-400 text-sm mb-2">اللحظة الدقيقة للتصادم</p>
                <p className="text-white">{new Date(displayIncident.createdAt).toLocaleTimeString("ar-SA")}</p>
              </div>
              <div className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 p-4 rounded-lg border border-purple-500/20">
                <p className="text-gray-400 text-sm mb-2">الصورة التوضيحية</p>
                <p className="text-white">متاحة في نظام INCIQ</p>
              </div>
            </div>
          </Card>

          {/* 5. Traffic Impact Assessment */}
          <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <Activity className="w-6 h-6 text-orange-500" />
              تقييم تأثير الحادث على الحركة المرورية
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">مستوى التأثير</p>
                <Badge className="bg-orange-500/20 text-orange-300">متوسط</Badge>
              </div>
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">عدد المسارات المعطلة</p>
                <p className="text-white font-semibold">2 مسار</p>
              </div>
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">طول طابور المركبات المتوقع</p>
                <p className="text-white font-semibold">500 متر</p>
              </div>
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">الزمن المتوقع لعودة الانسيابية</p>
                <p className="text-white font-semibold">15 دقيقة</p>
              </div>
            </div>
            <div className="bg-cyan-500/10 border border-cyan-500/20 p-4 rounded-lg">
              <p className="text-gray-400 text-sm mb-2">قرار النظام</p>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-yellow-500/20 text-yellow-300">استدعاء السطحة</Badge>
                <Badge className="bg-red-500/20 text-red-300">إرسال إسعاف</Badge>
                <Badge className="bg-blue-500/20 text-blue-300">تدخل مروري</Badge>
              </div>
            </div>
          </Card>

          {/* 6. Fault Assessment */}
          <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <AlertTriangle className="w-6 h-6 text-red-500" />
              نسبة الخطأ التقديرية (AI Fault Assessment)
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              باستخدام خوارزميات تحليل السلوك المروري وقواعد المرور:
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="text-right py-3 px-4 text-gray-400">الطرف</th>
                    <th className="text-right py-3 px-4 text-gray-400">نسبة الخطأ</th>
                    <th className="text-right py-3 px-4 text-gray-400">أسباب التقدير</th>
                  </tr>
                </thead>
                <tbody>
                  {displayParties.map((party) => (
                    <tr key={party.id} className="border-b border-white/5 hover:bg-white/5">
                      <td className="py-3 px-4 text-white">{party.partyName}</td>
                      <td className="py-3 px-4">
                        <Badge className={party.faultPercentage! > 50 ? "bg-red-500/20 text-red-300" : "bg-green-500/20 text-green-300"}>
                          {party.faultPercentage}%
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-gray-300">
                        {party.faultPercentage! > 50
                          ? "عدم الانتباه، تجاوز السرعة المسموحة"
                          : "عدم ترك مسافة آمنة"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-gray-400 text-sm mt-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
              ملاحظة: النسبة قابلة للتعديل من المرور أو نجم بعد المراجعة الرسمية.
            </p>
          </Card>

          {/* 7. Road Conditions */}
          <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <Zap className="w-6 h-6 text-yellow-500" />
              حالة الطريق لحظة البلاغ
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">سرعة التدفق المروري</p>
                <p className="text-white font-semibold">45 كم/س</p>
              </div>
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">كثافة المركبات</p>
                <p className="text-white font-semibold">65%</p>
              </div>
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">وجود عوائق إضافية</p>
                <Badge className="bg-green-500/20 text-green-300">لا</Badge>
              </div>
              <div className="bg-white/5 p-4 rounded-lg border border-white/10">
                <p className="text-gray-400 text-sm mb-2">احتمالية وقوع حوادث ثانوية</p>
                <p className="text-white font-semibold">35%</p>
              </div>
            </div>
          </Card>

          {/* 8. Response Actions */}
          <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <Shield className="w-6 h-6 text-green-500" />
              الاستجابة التي تم اتخاذها
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/10">
                <span className="text-white">إشعار المرور</span>
                <Badge className="bg-green-500/20 text-green-300">تم</Badge>
              </div>
              <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/10">
                <span className="text-white">توجيه الإسعاف</span>
                <Badge className="bg-green-500/20 text-green-300">تم</Badge>
              </div>
              <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/10">
                <span className="text-white">توجيه السطحة</span>
                <Badge className="bg-green-500/20 text-green-300">تم</Badge>
              </div>
              <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/10">
                <span className="text-white">وقت وصول أول جهة للموقع</span>
                <Badge className="bg-cyan-500/20 text-cyan-300">8 دقائق</Badge>
              </div>
            </div>
          </Card>

          {/* 9. Error Rate & Analysis */}
          <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/20 p-6 backdrop-blur-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-white flex items-center gap-2">
                <TrendingUp className="w-6 h-6 text-cyan-500" />
                نسبة الخطأ والدقة
              </h3>
              <Badge className="bg-cyan-500/20 text-cyan-300 border-cyan-500/30">{displayIncident.severity}</Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="text-5xl font-bold text-cyan-500 mb-2">{errorRate}%</p>
                <p className="text-gray-400">نسبة الخطأ المحسوبة</p>
              </div>
              <div>
                <p className="text-5xl font-bold text-green-500 mb-2">{accuracy}%</p>
                <p className="text-gray-400">دقة التحليل</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm mt-4">
              تم تحليل الحادث بواسطة نظام INCIQ مع نسبة دقة {accuracy}%
            </p>
          </Card>

          {/* 10. Repair Sheet */}
          <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
            <h3 className="text-xl font-semibold text-white mb-6 flex items-center gap-2">
              <Wrench className="w-6 h-6 text-orange-500" />
              ورقة الإصلاح
            </h3>
            <div className="p-4 rounded-lg border bg-orange-500/10 border-orange-500/20">
              <div className="flex items-start justify-between mb-2">
                <h4 className="text-lg font-semibold text-white">{repairItem.title}</h4>
                <Badge className="bg-orange-500/20 text-orange-300">عالي</Badge>
              </div>
              <p className="text-gray-400 mb-3">{repairItem.description}</p>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-gray-500">💰</span>
                  <div>
                    <p className="text-gray-400 text-sm">التكلفة</p>
                    <p className="text-cyan-400 font-semibold">متروك لتقدير شركة التأمين</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-gray-500" />
                  <div>
                    <p className="text-gray-400 text-sm">الوقت</p>
                    <p className="text-cyan-400 font-semibold">{repairItem.estimatedTime}</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* 11. Recommendations */}
          <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <CheckCircle className="w-6 h-6 text-green-500" />
              التوصيات
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <span className="text-green-500 mt-1">•</span>
                <span className="text-gray-300">نقل السيارة إلى ورشة متخصصة للإصلاح</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-green-500 mt-1">•</span>
                <span className="text-gray-300">الحصول على تقرير طبي للركاب</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-green-500 mt-1">•</span>
                <span className="text-gray-300">التواصل مع شركة التأمين</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-green-500 mt-1">•</span>
                <span className="text-gray-300">توثيق الحادث رسمياً لدى الجهات المختصة</span>
              </li>
            </ul>
          </Card>

          {/* 12. Report Outputs */}
          <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
            <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <FileText className="w-6 h-6 text-blue-500" />
              مخرجات التقرير
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="text-gray-300">نسخة إلكترونية للطرفين</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="text-gray-300">رفع التقرير لشركات التأمين تلقائيًا</span>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                <span className="text-gray-300">حفظ في سجل INCIQ لمدة 90 يومًا (حسب السياسة)</span>
              </li>
            </ul>
          </Card>

          {/* 13. Send Status */}
          {reportSends && reportSends.length > 0 && (
            <Card className="bg-white/5 border-white/10 p-6 backdrop-blur-sm">
              <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                <CheckCheck className="w-6 h-6 text-green-500" />
                حالة الإرسالات
              </h3>
              <div className="space-y-3">
                {reportSends.map((send) => (
                  <div key={send.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/10">
                    <div>
                      <p className="text-white font-semibold">{send.recipientName || send.recipientEmail}</p>
                      <p className="text-gray-400 text-sm">
                        {send.recipientType === "party"
                          ? "طرف متورط"
                          : send.recipientType === "najm"
                          ? "شركة نجم"
                          : send.recipientType === "insurance"
                          ? "شركة التأمين"
                          : "مشغل"}
                      </p>
                    </div>
                    <Badge
                      className={
                        send.status === "sent"
                          ? "bg-green-500/20 text-green-300"
                          : send.status === "read"
                          ? "bg-blue-500/20 text-blue-300"
                          : send.status === "failed"
                          ? "bg-red-500/20 text-red-300"
                          : "bg-yellow-500/20 text-yellow-300"
                      }
                    >
                      {send.status === "sent"
                        ? "مرسل"
                        : send.status === "read"
                        ? "مقروء"
                        : send.status === "failed"
                        ? "فشل"
                        : "قيد الانتظار"}
                    </Badge>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* 14. System Signature */}
          <Card className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border-cyan-500/20 p-6 backdrop-blur-sm text-center">
            <h3 className="text-xl font-semibold text-white mb-2">توقيع النظام</h3>
            <p className="text-gray-400 mb-2">INCIQ – Automated Incident Decision Engine</p>
            <p className="text-gray-500 text-sm">
              هذا التقرير أُصدر بالكامل باستخدام الذكاء الاصطناعي وتحليل الطرق الحي.
            </p>
            <p className="text-gray-500 text-xs mt-2">{new Date().toLocaleString("ar-SA")}</p>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="mt-8 flex flex-wrap gap-4 justify-center">
          <Button
            onClick={handleDownloadPDF}
            className="bg-cyan-600 hover:bg-cyan-700 text-white flex items-center gap-2"
          >
            <Download className="w-5 h-5" />
            تحميل PDF
          </Button>
          <Button
            onClick={handlePrint}
            className="bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2"
          >
            <Printer className="w-5 h-5" />
            طباعة
          </Button>
          <Button
            onClick={handleOpenMap}
            className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
          >
            <Map className="w-5 h-5" />
            فتح الخريطة
          </Button>
          <Button
            onClick={handleSendReport}
            disabled={isSending || sendReportMutation.isPending}
            className="bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-2 disabled:opacity-50"
          >
            {isSending || sendReportMutation.isPending ? (
              <>
                <Loader className="w-5 h-5 animate-spin" />
                جاري الإرسال...
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                إرسال التقرير
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
