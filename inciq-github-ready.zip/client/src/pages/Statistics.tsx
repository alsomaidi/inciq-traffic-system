import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { TrendingUp, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Statistics() {
  const incidentsQuery = trpc.incidents.list.useQuery({ limit: 1000 });
  const incidents = incidentsQuery.data || [];

  // حساب الإحصائيات
  const totalIncidents = incidents.length;
  const injuryIncidents = incidents.filter(
    (i) => i.incidentType === "injury"
  ).length;
  const breakdownIncidents = incidents.filter(
    (i) => i.incidentType === "breakdown"
  ).length;
  const trafficIncidents = incidents.filter(
    (i) => i.incidentType === "traffic"
  ).length;

  const resolvedIncidents = incidents.filter(
    (i) => i.status === "resolved" || i.status === "closed"
  ).length;

  const criticalIncidents = incidents.filter(
    (i) => i.severity === "critical"
  ).length;

  // بيانات الرسم البياني - توزيع الحوادث
  const incidentTypeData = [
    { name: "إصابات", value: injuryIncidents, fill: "#ef4444" },
    { name: "تعطل سيارة", value: breakdownIncidents, fill: "#f97316" },
    { name: "تسيير", value: trafficIncidents, fill: "#3b82f6" },
  ];

  // بيانات الرسم البياني - حالة الحوادث
  const statusData = [
    {
      name: "قيد الانتظار",
      value: incidents.filter((i) => i.status === "pending").length,
    },
    {
      name: "مسند",
      value: incidents.filter((i) => i.status === "assigned").length,
    },
    {
      name: "قيد المعالجة",
      value: incidents.filter((i) => i.status === "in_progress").length,
    },
    {
      name: "تم حله",
      value: incidents.filter((i) => i.status === "resolved").length,
    },
    {
      name: "مغلق",
      value: incidents.filter((i) => i.status === "closed").length,
    },
  ];

  // بيانات الرسم البياني - درجة الخطورة
  const severityData = [
    {
      name: "منخفضة",
      value: incidents.filter((i) => i.severity === "low").length,
    },
    {
      name: "متوسطة",
      value: incidents.filter((i) => i.severity === "medium").length,
    },
    {
      name: "عالية",
      value: incidents.filter((i) => i.severity === "high").length,
    },
    {
      name: "حرجة",
      value: incidents.filter((i) => i.severity === "critical").length,
    },
  ];

  const COLORS = ["#22c55e", "#eab308", "#f97316", "#ef4444"];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4 md:p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-800">الإحصائيات والتقارير</h1>
          <p className="text-gray-600 mt-1">تحليل بيانات الحوادث المرورية</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4 md:p-8">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {/* Total Incidents */}
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm mb-1">إجمالي الحوادث</p>
                <p className="text-3xl font-bold text-gray-800">{totalIncidents}</p>
              </div>
              <AlertTriangle className="w-12 h-12 text-blue-500 opacity-20" />
            </div>
          </Card>

          {/* Resolved Incidents */}
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm mb-1">الحوادث المحلولة</p>
                <p className="text-3xl font-bold text-gray-800">{resolvedIncidents}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {totalIncidents > 0
                    ? `${Math.round((resolvedIncidents / totalIncidents) * 100)}%`
                    : "0%"}
                </p>
              </div>
              <CheckCircle className="w-12 h-12 text-green-500 opacity-20" />
            </div>
          </Card>

          {/* Critical Incidents */}
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm mb-1">حوادث حرجة</p>
                <p className="text-3xl font-bold text-gray-800">{criticalIncidents}</p>
              </div>
              <TrendingUp className="w-12 h-12 text-red-500 opacity-20" />
            </div>
          </Card>

          {/* Average Resolution Time */}
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm mb-1">متوسط وقت الحل</p>
                <p className="text-3xl font-bold text-gray-800">~15 دقيقة</p>
              </div>
              <Clock className="w-12 h-12 text-orange-500 opacity-20" />
            </div>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Incident Type Distribution */}
          <Card className="p-6">
            <h2 className="text-lg font-bold text-gray-800 mb-4">
              توزيع أنواع الحوادث
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={incidentTypeData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {incidentTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Card>

          {/* Severity Distribution */}
          <Card className="p-6">
            <h2 className="text-lg font-bold text-gray-800 mb-4">
              توزيع درجات الخطورة
            </h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={severityData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Status Distribution */}
        <Card className="p-6 mb-8">
          <h2 className="text-lg font-bold text-gray-800 mb-4">
            توزيع حالات الحوادث
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={statusData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#8b5cf6" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Incident Details Table */}
        <Card className="p-6">
          <h2 className="text-lg font-bold text-gray-800 mb-4">
            قائمة الحوادث التفصيلية
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-right font-semibold text-gray-700">
                    النوع
                  </th>
                  <th className="px-4 py-3 text-right font-semibold text-gray-700">
                    الموقع
                  </th>
                  <th className="px-4 py-3 text-right font-semibold text-gray-700">
                    الحالة
                  </th>
                  <th className="px-4 py-3 text-right font-semibold text-gray-700">
                    الخطورة
                  </th>
                  <th className="px-4 py-3 text-right font-semibold text-gray-700">
                    الوقت
                  </th>
                </tr>
              </thead>
              <tbody>
                {incidents.slice(0, 10).map((incident) => (
                  <tr key={incident.id} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <Badge className="bg-blue-100 text-blue-800">
                        {incident.incidentType === "injury"
                          ? "إصابات"
                          : incident.incidentType === "breakdown"
                          ? "تعطل"
                          : "تسيير"}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-gray-700">
                      {incident.location.substring(0, 30)}...
                    </td>
                    <td className="px-4 py-3">
                      <Badge
                        className={
                          incident.status === "pending"
                            ? "bg-yellow-100 text-yellow-800"
                            : incident.status === "assigned"
                            ? "bg-blue-100 text-blue-800"
                            : incident.status === "in_progress"
                            ? "bg-purple-100 text-purple-800"
                            : incident.status === "resolved"
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                        }
                      >
                        {incident.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3">
                      <Badge
                        className={
                          incident.severity === "critical"
                            ? "bg-red-100 text-red-800"
                            : incident.severity === "high"
                            ? "bg-orange-100 text-orange-800"
                            : incident.severity === "medium"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-green-100 text-green-800"
                        }
                      >
                        {incident.severity}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-gray-600 text-xs">
                      {new Date(incident.reportedAt).toLocaleString("ar-SA")}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}
