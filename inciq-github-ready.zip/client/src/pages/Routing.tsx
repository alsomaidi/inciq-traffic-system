import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  MapPin,
  Navigation,
  Clock,
  AlertCircle,
  CheckCircle,
  Zap,
  ArrowRight,
} from "lucide-react";
import { toast } from "sonner";

interface Service {
  id: string;
  name: string;
  type: "ambulance" | "police" | "tow" | "fire";
  status: "available" | "en-route" | "arrived";
  distance: number;
  eta: number;
  location: { lat: number; lng: number };
  currentLocation: { lat: number; lng: number };
  phone: string;
}

interface IncidentData {
  id: string;
  type: string;
  location: string;
  coordinates: { lat: number; lng: number };
  severity: "low" | "medium" | "high";
  timestamp: number;
}

export default function Routing() {
  const [incident, setIncident] = useState<IncidentData | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [optimizedRoute, setOptimizedRoute] = useState<Service[]>([]);
  const [isOptimizing, setIsOptimizing] = useState(false);

  useEffect(() => {
    // محاكاة تحميل بيانات الحادث من localStorage أو API
    const mockIncident: IncidentData = {
      id: "#1234",
      type: "تصادم سيارتين",
      location: "طريق الملك فهد - الرياض",
      coordinates: { lat: 24.7136, lng: 46.6753 },
      severity: "high",
      timestamp: Date.now() - 15 * 60 * 1000, // 15 دقائق مضت
    };

    const mockServices: Service[] = [
      {
        id: "ambulance-45",
        name: "إسعاف رقم 45",
        type: "ambulance",
        status: "en-route",
        distance: 2.5,
        eta: 3,
        location: { lat: 24.7136, lng: 46.6753 },
        currentLocation: { lat: 24.7200, lng: 46.6800 },
        phone: "+966501234567",
      },
      {
        id: "police-8",
        name: "دورية مرور رقم 8",
        type: "police",
        status: "arrived",
        distance: 0.8,
        eta: 0,
        location: { lat: 24.7136, lng: 46.6753 },
        currentLocation: { lat: 24.7140, lng: 46.6750 },
        phone: "+966501234568",
      },
      {
        id: "tow-12",
        name: "سطحة رقم 12",
        type: "tow",
        status: "en-route",
        distance: 4.2,
        eta: 5,
        location: { lat: 24.7136, lng: 46.6753 },
        currentLocation: { lat: 24.7100, lng: 46.6600 },
        phone: "+966501234569",
      },
      {
        id: "fire-3",
        name: "فريق الإطفاء رقم 3",
        type: "fire",
        status: "available",
        distance: 6.5,
        eta: 8,
        location: { lat: 24.7136, lng: 46.6753 },
        currentLocation: { lat: 24.6900, lng: 46.6500 },
        phone: "+966501234570",
      },
    ];

    setIncident(mockIncident);
    setServices(mockServices);
    setOptimizedRoute(mockServices);
  }, []);

  const handleOptimizeRoute = () => {
    setIsOptimizing(true);
    toast.loading("جاري تحسين المسار...");

    setTimeout(() => {
      // محاكاة تحسين المسار
      const optimized = [...services].sort((a, b) => {
        // ترتيب حسب الأولوية والمسافة
        const priorityMap = { ambulance: 1, police: 2, fire: 3, tow: 4 };
        const priorityDiff =
          priorityMap[a.type] - priorityMap[b.type];
        if (priorityDiff !== 0) return priorityDiff;
        return a.distance - b.distance;
      });

      setOptimizedRoute(optimized);
      setIsOptimizing(false);
      toast.success("تم تحسين المسار بنجاح!");
    }, 2000);
  };

  const handleCallService = (service: Service) => {
    toast.success(`جاري الاتصال بـ ${service.name}...`);
    // في تطبيق حقيقي، سيتم الاتصال بـ API لتنفيذ المكالمة
  };

  const getServiceIcon = (type: string) => {
    switch (type) {
      case "ambulance":
        return "🚑";
      case "police":
        return "🚔";
      case "tow":
        return "🚗";
      case "fire":
        return "🚒";
      default:
        return "📍";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-500/20 text-green-400";
      case "en-route":
        return "bg-blue-500/20 text-blue-400";
      case "arrived":
        return "bg-purple-500/20 text-purple-400";
      default:
        return "bg-gray-500/20 text-gray-400";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "available":
        return "متاح";
      case "en-route":
        return "في الطريق";
      case "arrived":
        return "وصل";
      default:
        return "غير معروف";
    }
  };

  if (!incident) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin mb-4">
            <Zap className="w-12 h-12 text-cyan-400" />
          </div>
          <p className="text-white text-lg">جاري تحميل بيانات الحادث...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-6xl mx-auto">
        {/* رأس الصفحة */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            نظام التوجيه الآلي
          </h1>
          <p className="text-slate-400">
            توجيه الخدمات الطوارئ بكفاءة إلى موقع الحادث
          </p>
        </div>

        {/* معلومات الحادث */}
        <Card className="bg-slate-800/50 border-slate-700 mb-8 p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <p className="text-slate-400 text-sm mb-1">رقم البلاغ</p>
              <p className="text-white text-lg font-semibold">{incident.id}</p>
            </div>
            <div>
              <p className="text-slate-400 text-sm mb-1">نوع الحادث</p>
              <p className="text-white text-lg font-semibold">
                {incident.type}
              </p>
            </div>
            <div>
              <p className="text-slate-400 text-sm mb-1">الموقع</p>
              <p className="text-white text-lg font-semibold">
                {incident.location}
              </p>
            </div>
            <div>
              <p className="text-slate-400 text-sm mb-1">مستوى الخطورة</p>
              <Badge
                className={
                  incident.severity === "high"
                    ? "bg-red-500/20 text-red-400"
                    : incident.severity === "medium"
                      ? "bg-yellow-500/20 text-yellow-400"
                      : "bg-green-500/20 text-green-400"
                }
              >
                {incident.severity === "high"
                  ? "عالي"
                  : incident.severity === "medium"
                    ? "متوسط"
                    : "منخفض"}
              </Badge>
            </div>
          </div>
        </Card>

        {/* أزرار التحكم */}
        <div className="flex gap-4 mb-8">
          <Button
            onClick={handleOptimizeRoute}
            disabled={isOptimizing}
            className="bg-cyan-500 hover:bg-cyan-600 text-white"
          >
            <Navigation className="w-4 h-4 mr-2" />
            {isOptimizing ? "جاري التحسين..." : "تحسين المسار"}
          </Button>
          <Button
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            <MapPin className="w-4 h-4 mr-2" />
            عرض الخريطة
          </Button>
        </div>

        {/* قائمة الخدمات المُوجهة */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {optimizedRoute.map((service, index) => (
            <Card
              key={service.id}
              className="bg-slate-800/50 border-slate-700 p-6 hover:border-cyan-500/50 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="text-3xl">
                    {getServiceIcon(service.type)}
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-lg">
                      {service.name}
                    </h3>
                    <p className="text-slate-400 text-sm">
                      الأولوية: #{index + 1}
                    </p>
                  </div>
                </div>
                <Badge className={getStatusColor(service.status)}>
                  {getStatusText(service.status)}
                </Badge>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    المسافة
                  </span>
                  <span className="text-white font-semibold">
                    {service.distance} كم
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    الوقت المتوقع
                  </span>
                  <span className="text-white font-semibold">
                    {service.eta} دقائق
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    الموقع الحالي
                  </span>
                  <span className="text-white font-semibold text-sm">
                    {service.currentLocation.lat.toFixed(4)},
                    {service.currentLocation.lng.toFixed(4)}
                  </span>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={() => handleCallService(service)}
                  className="flex-1 bg-green-500 hover:bg-green-600 text-white"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  اتصل الآن
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  <ArrowRight className="w-4 h-4 mr-2" />
                  التفاصيل
                </Button>
              </div>

              {/* شريط التقدم */}
              <div className="mt-4 pt-4 border-t border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-400 text-xs">التقدم</span>
                  <span className="text-cyan-400 text-xs font-semibold">
                    {Math.min(
                      100,
                      Math.round(((service.distance - 0.5) / service.distance) * 100)
                    )}
                    %
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full transition-all"
                    style={{
                      width: `${Math.min(
                        100,
                        Math.round(((service.distance - 0.5) / service.distance) * 100)
                      )}%`,
                    }}
                  />
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* معلومات إضافية */}
        <Card className="bg-slate-800/50 border-slate-700 mt-8 p-6">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-400 mt-1 flex-shrink-0" />
            <div>
              <h4 className="text-white font-semibold mb-2">
                تم تحسين المسار تلقائياً
              </h4>
              <p className="text-slate-400 text-sm">
                تم ترتيب الخدمات بناءً على الأولوية والمسافة والوقت المتوقع
                للوصول. يتم تحديث المعلومات في الوقت الفعلي.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
