import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  Zap,
  Shield,
  BarChart3,
  MapPin,
  Bell,
  Star,
  ArrowRight,
  Satellite,
  Camera,
  Smartphone,
  TrendingUp,
  Target,
  Rocket,
} from "lucide-react";
import { useLocation } from "wouter";

export default function Home() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [, navigate] = useLocation();

  const handleMouseMove = (e: React.MouseEvent) => {
    const { clientX, clientY } = e;
    const { innerWidth, innerHeight } = window;
    setMousePosition({
      x: (clientX / innerWidth) * 100,
      y: (clientY / innerHeight) * 100,
    });
  };

  const handleFeatureClick = (featureTitle: string) => {
    const routes: { [key: string]: string } = {
      "معالجة فورية": "/inciq",
      "تحديد الموقع": "/tracking",
      "تقارير ذكية": "/smart-report",
      "تنبيهات ذكية": "/notifications",
      "توجيه آلي": "/routing",
      "تقييم الخدمة": "/feedback",
    };

    const route = routes[featureTitle];
    if (route) {
      toast.success(`جاري الانتقال إلى ${featureTitle}...`);
      navigate(route);
    } else {
      toast.info(`ميزة ${featureTitle} قيد التطوير`);
    }
  };

  const features = [
    {
      icon: Zap,
      title: "معالجة فورية",
      desc: "تحليل الحوادث خلال ثوان باستخدام الذكاء الاصطناعي",
    },
    {
      icon: MapPin,
      title: "تحديد الموقع",
      desc: "تحديد دقيق للموقع الجغرافي باستخدام GPS",
    },
    {
      icon: BarChart3,
      title: "تقارير ذكية",
      desc: "تقارير تفصيلية مع نسبة الخطأ والمسؤولية",
    },
    {
      icon: Bell,
      title: "تنبيهات ذكية",
      desc: "تنبيهات فورية وذكية للأطراف المعنية",
    },
    {
      icon: Shield,
      title: "توجيه آلي",
      desc: "توجيه الخدمات (إسعاف، سطحة، مرور) تلقائياً",
    },
    {
      icon: Star,
      title: "تقييم الخدمة",
      desc: "تقييم وملاحظات المستخدمين لتحسين الخدمة",
    },
  ];

  const stats = [
    { label: "دقة التقارير", value: "95%" },
    { label: "تقليل الازدحام", value: "70%" },
    { label: "منع الحوادث الثانوية", value: "60%" },
    { label: "وقت الاستجابة", value: "<1 ثانية" },
  ];

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-[#0f0f1e] via-[#1a1a2e] to-[#0f0f1e] text-white overflow-hidden"
      onMouseMove={handleMouseMove}
    >
      {/* Animated Background */}
      <div className="fixed inset-0 pointer-events-none">
        <div
          className="absolute w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl"
          style={{
            left: `${mousePosition.x}%`,
            top: `${mousePosition.y}%`,
            transform: "translate(-50%, -50%)",
            transition: "all 0.3s ease-out",
          }}
        />
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-white/10 backdrop-blur-md bg-white/5">
        <div className="max-w-7xl mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/inciq-logo.png" alt="INCIQ" className="w-10 h-10" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              INCIQ
            </h1>
          </div>
          <nav className="hidden md:flex gap-8">
            {[
              { path: "/inciq", label: "التطبيق" },
              { path: "/dashboard", label: "لوحة التحكم" },
              { path: "/tracking", label: "التتبع" },
              { path: "/feedback", label: "التقييم" },
            ].map((item) => (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className="text-sm text-gray-300 hover:text-cyan-400 transition-colors"
              >
                {item.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <main className="relative z-10">
        <section className="max-w-7xl mx-auto px-4 py-20 text-center">
          <div className="mb-8">
            <img
              src="/inciq-logo.png"
              alt="INCIQ"
              className="w-32 h-32 mx-auto mb-6 drop-shadow-2xl"
            />
          </div>
          <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 bg-clip-text text-transparent">
            منصة INCIQ الوطنية
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            منصة الذكاء الاصطناعي لمباشرة الحوادث ومنع الازدحام على الطرق الرئيسية
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={() => navigate("/inciq")}
              className="bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-bold py-6 px-8 text-lg rounded-lg hover:shadow-2xl hover:shadow-cyan-500/50 transition-all"
            >
              <Zap className="w-5 h-5 ml-2" />
              ابدأ الآن
            </Button>
            <Button
              onClick={() => navigate("/dashboard")}
              variant="outline"
              className="border-cyan-400 text-cyan-400 hover:bg-cyan-400/10 py-6 px-8 text-lg"
            >
              <Shield className="w-5 h-5 ml-2" />
              لوحة التحكم
            </Button>
          </div>
        </section>

        {/* Features Grid */}
        <section className="max-w-7xl mx-auto px-4 py-20">
          <h3 className="text-3xl font-bold text-center mb-12">
            المميزات الرئيسية
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <div
                  key={i}
                  onClick={() => handleFeatureClick(feature.title)}
                  className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-xl hover:bg-white/15 transition-all group cursor-pointer hover:shadow-lg hover:shadow-cyan-500/20 active:scale-95"
                >
                  <Icon className="w-12 h-12 text-cyan-400 mb-4 group-hover:scale-110 transition-transform" />
                  <h4 className="text-xl font-bold mb-2">{feature.title}</h4>
                  <p className="text-gray-300">{feature.desc}</p>
                </div>
              );
            })}
          </div>
        </section>

        {/* Technology Section */}
        <section className="max-w-7xl mx-auto px-4 py-20">
          <h3 className="text-3xl font-bold text-center mb-4">
            🛰️ التقنيات المستخدمة
          </h3>
          <p className="text-gray-300 text-center mb-12 max-w-2xl mx-auto">
            تكامل ذكي بين الذكاء الاصطناعي وإنترنت الأشياء لتغطية شاملة 360°
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-xl hover:bg-white/15 transition-all">
              <Satellite className="w-12 h-12 text-cyan-400 mb-4" />
              <h4 className="text-xl font-bold mb-3">📡 الأقمار الصناعية</h4>
              <ul className="text-gray-300 space-y-2 text-sm">
                <li>• Planet Labs (دقة 3-5 متر)</li>
                <li>• Sentinel-2 (مجاني ومفتوح)</li>
                <li>• ICEYE (رادار ليلي)</li>
                <li>• تحديثات يومية شاملة</li>
              </ul>
            </div>
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-xl hover:bg-white/15 transition-all">
              <Camera className="w-12 h-12 text-cyan-400 mb-4" />
              <h4 className="text-xl font-bold mb-3">📹 الكاميرات الذكية</h4>
              <ul className="text-gray-300 space-y-2 text-sm">
                <li>• كاميرات المراقبة الأرضية</li>
                <li>• تحليل AI فوري (YOLOv8)</li>
                <li>• كشف تلقائي للحوادث</li>
                <li>• تغطية 24/7</li>
              </ul>
            </div>
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-xl hover:bg-white/15 transition-all">
              <Smartphone className="w-12 h-12 text-cyan-400 mb-4" />
              <h4 className="text-xl font-bold mb-3">📱 تطبيق المواطنين</h4>
              <ul className="text-gray-300 space-y-2 text-sm">
                <li>• إبلاغ فوري بالصور</li>
                <li>• تحديد GPS دقيق</li>
                <li>• واجهة سهلة بالعربية</li>
                <li>• تحليل AI في ثانية</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Roadmap Section */}
        <section className="max-w-7xl mx-auto px-4 py-20">
          <h3 className="text-3xl font-bold text-center mb-4">
            🗺️ خارطة الطريق
          </h3>
          <p className="text-gray-300 text-center mb-12 max-w-2xl mx-auto">
            رؤية متكاملة للتطوير المستمر والتوسع المستقبلي
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-green-500/20 to-green-600/10 backdrop-blur-md border border-green-400/30 p-6 rounded-xl">
              <div className="flex items-center gap-2 mb-4">
                <Target className="w-8 h-8 text-green-400" />
                <h4 className="text-xl font-bold">المرحلة 1 (الحالية)</h4>
              </div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                <span className="text-green-400 text-sm font-bold">قيد التشغيل</span>
              </div>
              <ul className="text-gray-300 space-y-2 text-sm">
                <li>✅ تطبيق المواطنين</li>
                <li>✅ تحليل AI (YOLOv8 + Claude)</li>
                <li>✅ تتبع GPS فوري</li>
                <li>✅ توجيه الخدمات</li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 backdrop-blur-md border border-blue-400/30 p-6 rounded-xl">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="w-8 h-8 text-blue-400" />
                <h4 className="text-xl font-bold">المرحلة 2 (قريباً)</h4>
              </div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 bg-blue-400 rounded-full" />
                <span className="text-blue-400 text-sm font-bold">قيد التطوير</span>
              </div>
              <ul className="text-gray-300 space-y-2 text-sm">
                <li>🔄 كاميرات المراقبة الذكية</li>
                <li>🔄 تكامل Google Maps</li>
                <li>🔄 إشعارات فورية</li>
                <li>🔄 تطبيق موبايل</li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-purple-500/20 to-purple-600/10 backdrop-blur-md border border-purple-400/30 p-6 rounded-xl">
              <div className="flex items-center gap-2 mb-4">
                <Rocket className="w-8 h-8 text-purple-400" />
                <h4 className="text-xl font-bold">المرحلة 3 (مستقبلاً)</h4>
              </div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 bg-purple-400 rounded-full" />
                <span className="text-purple-400 text-sm font-bold">الرؤية المستقبلية</span>
              </div>
              <ul className="text-gray-300 space-y-2 text-sm">
                <li>🚀 تكامل الأقمار الصناعية</li>
                <li>🚀 كشف تلقائي للحوادث</li>
                <li>🚀 تغطية على مستوى المملكة</li>
                <li>🚀 التنبؤ بالحوادث</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="max-w-7xl mx-auto px-4 py-20">
          <h3 className="text-3xl font-bold text-center mb-12">
            الفوائد المتوقعة
          </h3>
          <div className="grid md:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <div
                key={i}
                className="bg-white/10 backdrop-blur-md border border-white/20 p-6 text-center rounded-xl hover:bg-white/15 transition-all"
              >
                <p className="text-3xl font-bold text-cyan-400 mb-2">
                  {stat.value}
                </p>
                <p className="text-gray-300">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="max-w-7xl mx-auto px-4 py-20">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 p-12 rounded-2xl text-center">
            <h3 className="text-3xl font-bold mb-4">
              جاهز لتحسين السلامة المرورية؟
            </h3>
            <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
              انضم إلينا في ثورة الذكاء الاصطناعي لمباشرة الحوادث والحد من الازدحام
            </p>
            <Button
              onClick={() => navigate("/inciq")}
              className="bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-bold py-6 px-12 text-lg rounded-lg hover:shadow-2xl hover:shadow-cyan-500/50 transition-all"
            >
              ابدأ الآن
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-white/10 backdrop-blur-md bg-white/5 mt-20">
          <div className="max-w-7xl mx-auto px-4 py-8 text-center text-gray-400">
            <p>منصة INCIQ الوطنية © 2025 - جميع الحقوق محفوظة</p>
          </div>
        </footer>
      </main>
    </div>
  );
}
