import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function IncidentsMap() {
  const [selectedIncident, setSelectedIncident] = useState<number | null>(null);

  const incidentsQuery = trpc.incidents.list.useQuery({ limit: 100 });
  const incidents = incidentsQuery.data || [];

  const selectedIncidentData = incidents.find((i) => i.id === selectedIncident);

  const getIncidentIcon = (type: string) => {
    switch (type) {
      case "injury":
        return "🚑";
      case "breakdown":
        return "🚗";
      case "traffic":
        return "🚦";
      default:
        return "📍";
    }
  };

  const getIncidentTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      injury: "إصابات",
      breakdown: "تعطل سيارة",
      traffic: "تسيير",
    };
    return labels[type] || type;
  };

  const handleIncidentClick = (incident: any) => {
    setSelectedIncident(incident.id);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4 md:p-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-800">خريطة الحوادث</h1>
          <p className="text-gray-600 mt-1">متابعة الحوادث المرورية على الطرق الرئيسية</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4 md:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Map Placeholder */}
          <div className="lg:col-span-3">
            <Card className="p-4 h-[600px] bg-gradient-to-br from-blue-100 to-blue-50 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-blue-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">
                  خريطة الحوادث
                </h3>
                <p className="text-gray-600">
                  يتم عرض الحوادث على الخريطة التفاعلية هنا
                </p>
                <p className="text-sm text-gray-500 mt-2">
                  ({incidents.length} حادثة مسجلة)
                </p>
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-6 h-[600px] overflow-y-auto">
              <h2 className="text-lg font-bold text-gray-800 mb-4">
                الحوادث ({incidents.length})
              </h2>

              {incidentsQuery.isLoading ? (
                <div className="text-center py-8">
                  <p className="text-gray-600">جاري تحميل...</p>
                </div>
              ) : incidents.length === 0 ? (
                <div className="text-center py-8">
                  <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600">لا توجد حوادث</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {incidents.map((incident) => (
                    <div
                      key={incident.id}
                      onClick={() => handleIncidentClick(incident)}
                      className={`p-3 rounded-lg cursor-pointer transition-all border-2 ${
                        selectedIncident === incident.id
                          ? "border-blue-500 bg-blue-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <div className="flex items-start gap-2 mb-2">
                        <span className="text-2xl">
                          {getIncidentIcon(incident.incidentType)}
                        </span>
                        <div className="flex-1">
                          <p className="font-semibold text-sm text-gray-800">
                            {getIncidentTypeLabel(incident.incidentType)}
                          </p>
                          <p className="text-xs text-gray-600 line-clamp-2">
                            {incident.location}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-1 flex-wrap">
                        <Badge
                          className={`text-xs ${
                            incident.severity === "critical"
                              ? "bg-red-100 text-red-800"
                              : incident.severity === "high"
                              ? "bg-orange-100 text-orange-800"
                              : incident.severity === "medium"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-green-100 text-green-800"
                          }`}
                        >
                          {incident.severity}
                        </Badge>
                        <Badge
                          className={`text-xs ${
                            incident.status === "pending"
                              ? "bg-yellow-100 text-yellow-800"
                              : incident.status === "assigned"
                              ? "bg-blue-100 text-blue-800"
                              : incident.status === "in_progress"
                              ? "bg-purple-100 text-purple-800"
                              : incident.status === "resolved"
                              ? "bg-green-100 text-green-800"
                              : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {incident.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        </div>

        {/* Details Section */}
        {selectedIncidentData && (
          <Card className="mt-6 p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">
              تفاصيل الحادث المختار
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-gray-600 mb-1">النوع</p>
                <p className="font-semibold text-gray-800">
                  {getIncidentTypeLabel(selectedIncidentData.incidentType)}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">الموقع</p>
                <p className="font-semibold text-gray-800 text-sm">
                  {selectedIncidentData.location}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">الحالة</p>
                <Badge
                  className={
                    selectedIncidentData.status === "pending"
                      ? "bg-yellow-100 text-yellow-800"
                      : selectedIncidentData.status === "assigned"
                      ? "bg-blue-100 text-blue-800"
                      : selectedIncidentData.status === "in_progress"
                      ? "bg-purple-100 text-purple-800"
                      : selectedIncidentData.status === "resolved"
                      ? "bg-green-100 text-green-800"
                      : "bg-gray-100 text-gray-800"
                  }
                >
                  {selectedIncidentData.status}
                </Badge>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">الخطورة</p>
                <Badge
                  className={
                    selectedIncidentData.severity === "critical"
                      ? "bg-red-100 text-red-800"
                      : selectedIncidentData.severity === "high"
                      ? "bg-orange-100 text-orange-800"
                      : selectedIncidentData.severity === "medium"
                      ? "bg-yellow-100 text-yellow-800"
                      : "bg-green-100 text-green-800"
                  }
                >
                  {selectedIncidentData.severity}
                </Badge>
              </div>
            </div>
            {selectedIncidentData.description && (
              <div className="mt-4">
                <p className="text-sm text-gray-600 mb-2">الوصف</p>
                <p className="text-gray-700 bg-gray-50 p-3 rounded">
                  {selectedIncidentData.description}
                </p>
              </div>
            )}
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600 mb-1">الإحداثيات</p>
                <p className="text-sm font-mono text-gray-700 bg-gray-50 p-2 rounded">
                  {selectedIncidentData.latitude}, {selectedIncidentData.longitude}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">الوقت</p>
                <p className="text-sm text-gray-700">
                  {new Date(selectedIncidentData.reportedAt).toLocaleString("ar-SA")}
                </p>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
