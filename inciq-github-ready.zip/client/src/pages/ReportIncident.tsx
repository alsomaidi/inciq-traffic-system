import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AlertCircle, MapPin, CheckCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function ReportIncident() {
  const [formData, setFormData] = useState({
    incidentType: "traffic",
    location: "",
    latitude: "",
    longitude: "",
    description: "",
    severity: "medium",
  });

  const [loading, setLoading] = useState(false);
  const [geoLoading, setGeoLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const createIncidentMutation = trpc.incidents.create.useMutation();

  // الحصول على الموقع الجغرافي التلقائي
  const handleGetLocation = () => {
    setGeoLoading(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData((prev) => ({
            ...prev,
            latitude: position.coords.latitude.toString(),
            longitude: position.coords.longitude.toString(),
          }));
          setGeoLoading(false);
          toast.success("تم تحديد الموقع بنجاح");
        },
        (error) => {
          setGeoLoading(false);
          toast.error("فشل تحديد الموقع: " + error.message);
        }
      );
    } else {
      setGeoLoading(false);
      toast.error("المتصفح لا يدعم تحديد الموقع");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.location || !formData.latitude || !formData.longitude) {
      toast.error("يرجى ملء جميع الحقول المطلوبة");
      return;
    }

    setLoading(true);
    try {
      await createIncidentMutation.mutateAsync({
        incidentType: formData.incidentType as "injury" | "breakdown" | "traffic",
        location: formData.location,
        latitude: formData.latitude,
        longitude: formData.longitude,
        description: formData.description,
        severity: formData.severity as "low" | "medium" | "high" | "critical",
      });

      setSuccess(true);
      setFormData({
        incidentType: "traffic",
        location: "",
        latitude: "",
        longitude: "",
        description: "",
        severity: "medium",
      });

      setTimeout(() => setSuccess(false), 5000);
      toast.success("تم تقديم البلاغ بنجاح");
    } catch (error) {
      toast.error("فشل تقديم البلاغ");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
            تقديم بلاغ حادث مروري
          </h1>
          <p className="text-gray-600">
            يرجى تقديم تفاصيل دقيقة عن الحادث لمساعدتنا في الاستجابة السريعة
          </p>
        </div>

        {success && (
          <Card className="mb-6 bg-green-50 border-green-200 p-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <div>
                <h3 className="font-semibold text-green-900">تم التقديم بنجاح</h3>
                <p className="text-sm text-green-700">
                  سيتم الاستجابة لبلاغك في أقرب وقت ممكن
                </p>
              </div>
            </div>
          </Card>
        )}

        {/* Form Card */}
        <Card className="p-6 md:p-8 shadow-lg">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Incident Type */}
            <div>
              <Label htmlFor="incidentType" className="text-base font-semibold mb-2 block">
                نوع الحادث <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.incidentType}
                onValueChange={(value) =>
                  setFormData((prev) => ({ ...prev, incidentType: value }))
                }
              >
                <SelectTrigger id="incidentType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="injury">إصابات</SelectItem>
                  <SelectItem value="breakdown">تعطل سيارة</SelectItem>
                  <SelectItem value="traffic">تسيير (بدون توقف)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Location */}
            <div>
              <Label htmlFor="location" className="text-base font-semibold mb-2 block">
                موقع الحادث <span className="text-red-500">*</span>
              </Label>
              <Input
                id="location"
                placeholder="مثال: طريق الملك فهد، تقاطع شارع العليا"
                value={formData.location}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, location: e.target.value }))
                }
              />
            </div>

            {/* GPS Coordinates */}
            <div>
              <Label className="text-base font-semibold mb-3 block flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                الإحداثيات الجغرافية <span className="text-red-500">*</span>
              </Label>
              <div className="grid grid-cols-2 gap-4 mb-3">
                <div>
                  <Label htmlFor="latitude" className="text-sm mb-1 block">
                    خط العرض
                  </Label>
                  <Input
                    id="latitude"
                    placeholder="24.7136"
                    value={formData.latitude}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, latitude: e.target.value }))
                    }
                    readOnly
                  />
                </div>
                <div>
                  <Label htmlFor="longitude" className="text-sm mb-1 block">
                    خط الطول
                  </Label>
                  <Input
                    id="longitude"
                    placeholder="46.6753"
                    value={formData.longitude}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, longitude: e.target.value }))
                    }
                    readOnly
                  />
                </div>
              </div>
              <Button
                type="button"
                onClick={handleGetLocation}
                disabled={geoLoading}
                variant="outline"
                className="w-full"
              >
                {geoLoading ? "جاري تحديد الموقع..." : "تحديد موقعي الحالي"}
              </Button>
            </div>

            {/* Severity */}
            <div>
              <Label htmlFor="severity" className="text-base font-semibold mb-2 block">
                درجة الخطورة
              </Label>
              <Select
                value={formData.severity}
                onValueChange={(value) =>
                  setFormData((prev) => ({ ...prev, severity: value }))
                }
              >
                <SelectTrigger id="severity">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">منخفضة</SelectItem>
                  <SelectItem value="medium">متوسطة</SelectItem>
                  <SelectItem value="high">عالية</SelectItem>
                  <SelectItem value="critical">حرجة</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Description */}
            <div>
              <Label htmlFor="description" className="text-base font-semibold mb-2 block">
                وصف الحادث
              </Label>
              <Textarea
                id="description"
                placeholder="يرجى وصف الحادث بالتفصيل (عدد السيارات، الإصابات، حالة الطريق، إلخ)"
                value={formData.description}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, description: e.target.value }))
                }
                rows={5}
              />
            </div>

            {/* Info Box */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-800">
                <p className="font-semibold mb-1">معلومات مهمة:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>تأكد من دقة البيانات المقدمة</li>
                  <li>سيتم إرسال فريق الاستجابة السريعة</li>
                  <li>يمكنك متابعة حالة البلاغ من لوحة التحكم</li>
                </ul>
              </div>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 text-lg"
            >
              {loading ? "جاري التقديم..." : "تقديم البلاغ"}
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
}
