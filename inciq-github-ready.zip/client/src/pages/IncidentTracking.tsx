import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  MapPin,
  Ambulance,
  Truck,
  Car,
  Clock,
  AlertTriangle,
  Phone,
  Navigation,
} from "lucide-react";

interface Service {
  id: number;
  type: "ambulance" | "tow" | "police" | "traffic";
  name: string;
  status: "pending" | "en_route" | "arrived";
  eta: number; // بالدقائق
  distance: number; // بالكيلومتر
  phone: string;
  latitude: number;
  longitude: number;
}

interface Incident {
  id: number;
  location: string;
  type: string;
  status: string;
  severity: string;
  reportedTime: Date;
  latitude: number;
  longitude: number;
  services: Service[];
}

export default function IncidentTracking() {
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);

  // بيانات تجريبية للحوادث
  const incidents: Incident[] = [
    {
      id: 1234,
      location: "طريق الملك فهد - الرياض",
      type: "تصادم سيارتين",
      status: "قيد المعالجة",
      severity: "عالي",
      reportedTime: new Date(Date.now() - 15 * 60000),
      latitude: 24.7136,
      longitude: 46.6753,
      services: [
        {
          id: 1,
          type: "ambulance",
          name: "إسعاف رقم 45",
          status: "en_route",
          eta: 3,
          distance: 2.5,
          phone: "966112222222",
          latitude: 24.72,
          longitude: 46.68,
        },
        {
          id: 2,
          type: "tow",
          name: "سطحة رقم 12",
          status: "en_route",
          eta: 5,
          distance: 4.2,
          phone: "966550000000",
          latitude: 24.71,
          longitude: 46.66,
        },
        {
          id: 3,
          type: "police",
          name: "دورية مرور رقم 8",
          status: "arrived",
          eta: 0,
          distance: 0.8,
          phone: "966112255555",
          latitude: 24.714,
          longitude: 46.675,
        },
      ],
    },
  ];

  const incident = selectedIncident || incidents[0];

  const getServiceIcon = (type: string) => {
    switch (type) {
      case "ambulance":
        return <Ambulance className="w-8 h-8 text-red-500" />;
      case "tow":
        return <Truck className="w-8 h-8 text-yellow-500" />;
      case "police":
        return <Car className="w-8 h-8 text-blue-500" />;
      case "traffic":
        return <AlertTriangle className="w-8 h-8 text-orange-500" />;
      default:
        return <MapPin className="w-8 h-8 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge className="bg-gray-500 text-white">في الانتظار</Badge>;
      case "en_route":
        return <Badge className="bg-cyan-500 text-white">في الطريق</Badge>;
      case "arrived":
        return <Badge className="bg-green-500 text-white">وصلت</Badge>;
      default:
        return <Badge className="bg-gray-500 text-white">{status}</Badge>;
    }
  };

  const getServiceNameAr = (type: string) => {
    switch (type) {
      case "ambulance":
        return "الإسعاف";
      case "tow":
        return "السطحة";
      case "police":
        return "المرور";
      case "traffic":
        return "تنظيم المرور";
      default:
        return "خدمة";
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    return `منذ ${minutes} دقيقة`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto p-4 md:p-8">
        {/* Map and Info Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Map Card */}
          <div className="lg:col-span-2">
            <Card className="p-0 overflow-hidden bg-white/80 backdrop-blur-sm border-gray-200 shadow-lg">
              <div className="h-96 bg-gradient-to-br from-blue-100 to-cyan-50 flex items-center justify-center relative">
                <div className="absolute top-4 left-4 bg-white rounded-lg p-3 shadow-md">
                  <MapPin className="w-6 h-6 text-cyan-600" />
                </div>
                <div className="text-center z-10">
                  <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 shadow-xl max-w-md">
                    <h3 className="text-xl font-bold text-gray-800 mb-3">
                      خريطة تفاعلية
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 justify-center text-gray-700">
                        <MapPin className="w-4 h-4 text-cyan-600" />
                        <span className="font-semibold">موقع الحادث</span>
                      </div>
                      <p className="text-gray-600">
                        {incident.latitude.toFixed(4)}, {incident.longitude.toFixed(4)}
                      </p>
                      <p className="text-gray-800 font-semibold mt-3">
                        📍 {incident.location}
                      </p>
                      <p className="text-gray-700">
                        🚗 نوع الحادث: <span className="font-semibold">{incident.type}</span>
                      </p>
                    </div>
                    <div className="mt-4 flex gap-3 justify-center">
                      {incident.services.map((service) => (
                        <div
                          key={service.id}
                          className="w-12 h-12 rounded-full bg-white border-2 border-cyan-200 flex items-center justify-center shadow-md hover:scale-110 transition-transform"
                        >
                          {getServiceIcon(service.type)}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Incident Details Card */}
          <div>
            <Card className="p-6 bg-gray-900 text-white border-gray-700 shadow-lg">
              <h3 className="text-lg font-bold mb-4 text-cyan-400">
                رقم البلاغ
              </h3>
              <p className="text-3xl font-bold mb-6">#{incident.id}</p>
              
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-400 mb-1">الموقع</p>
                  <p className="font-semibold text-white text-sm">
                    {incident.location}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400 mb-1">النوع</p>
                  <p className="font-semibold text-white">{incident.type}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400 mb-1">الحالة</p>
                  <Badge className="bg-cyan-500 text-white mt-1">
                    {incident.status}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-gray-400 mb-1">وقت البلاغ</p>
                  <p className="text-sm text-white">
                    {formatTime(incident.reportedTime)}
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Services Section */}
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            الخدمات المطلوبة
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {incident.services.map((service) => (
              <Card
                key={service.id}
                className="p-6 bg-gray-900 text-white border-gray-700 shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-gray-800 rounded-lg">
                      {getServiceIcon(service.type)}
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-lg">
                        {getServiceNameAr(service.type)}
                      </h3>
                      <p className="text-sm text-gray-400">
                        {service.name}
                      </p>
                    </div>
                  </div>
                  {getStatusBadge(service.status)}
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-gray-800 rounded-lg p-3">
                    <p className="text-xs text-gray-400 mb-1">الوقت المتوقع</p>
                    <p className="font-bold text-white text-lg">
                      {service.eta === 0 ? "وصلت" : `${service.eta} دقائق`}
                    </p>
                  </div>
                  <div className="bg-gray-800 rounded-lg p-3">
                    <p className="text-xs text-gray-400 mb-1">المسافة</p>
                    <p className="font-bold text-white text-lg">
                      {service.distance} كم
                    </p>
                  </div>
                </div>

                <div className="bg-gray-800 rounded-lg p-3 mb-4">
                  <p className="text-xs text-gray-400 mb-1">الموقع الحالي</p>
                  <p className="text-xs text-gray-300">
                    {service.latitude.toFixed(4)}, {service.longitude.toFixed(4)}
                  </p>
                </div>

                <Button
                  onClick={() => window.open(`tel:${service.phone}`)}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold"
                >
                  <Phone className="w-4 h-4 ml-2" />
                  اتصل بالخدمة
                </Button>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
