import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Bell,
  CheckCircle,
  AlertTriangle,
  Clock,
  X,
  Settings,
} from "lucide-react";
import { toast } from "sonner";

interface Notification {
  id: number;
  type: "incident" | "service" | "update" | "alert";
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  actionUrl?: string;
}

export default function NotificationCenter() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 1,
      type: "incident",
      title: "تم استقبال بلاغك",
      message: "تم استقبال بلاغ الحادث برقم #1234 بنجاح",
      timestamp: new Date(Date.now() - 5 * 60000),
      read: false,
      actionUrl: "/inciq",
    },
    {
      id: 2,
      type: "service",
      title: "الإسعاف في الطريق",
      message: "وحدة الإسعاف رقم 45 في طريقها إلى موقع الحادث - ETA 3 دقائق",
      timestamp: new Date(Date.now() - 10 * 60000),
      read: false,
    },
    {
      id: 3,
      type: "update",
      title: "تم تحديث حالة الحادث",
      message: "تم تحديث حالة الحادث إلى 'قيد المعالجة' - نسبة الخطأ: 65%",
      timestamp: new Date(Date.now() - 15 * 60000),
      read: true,
    },
    {
      id: 4,
      type: "service",
      title: "السطحة في الطريق",
      message: "سطحة رقم 12 في طريقها لنقل السيارة - ETA 5 دقائق",
      timestamp: new Date(Date.now() - 20 * 60000),
      read: true,
    },
    {
      id: 5,
      type: "alert",
      title: "تنبيه مرور",
      message: "تحذير: ازدحام شديد على طريق الملك فهد في المنطقة المجاورة",
      timestamp: new Date(Date.now() - 30 * 60000),
      read: true,
    },
  ]);

  const [filter, setFilter] = useState<"all" | "unread" | "incident" | "service">("all");
  const [showSettings, setShowSettings] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const filteredNotifications = notifications.filter((n) => {
    if (filter === "unread") return !n.read;
    if (filter === "incident") return n.type === "incident";
    if (filter === "service") return n.type === "service";
    return true;
  });

  const markAsRead = (id: number) => {
    setNotifications(
      notifications.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter((n) => n.id !== id));
    toast.success("تم حذف الإشعار");
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })));
    toast.success("تم تحديد جميع الإشعارات كمقروءة");
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "incident":
        return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case "service":
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case "update":
        return <Clock className="w-5 h-5 text-blue-500" />;
      case "alert":
        return <Bell className="w-5 h-5 text-orange-500" />;
      default:
        return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "incident":
        return "bg-red-50 border-red-200";
      case "service":
        return "bg-green-50 border-green-200";
      case "update":
        return "bg-blue-50 border-blue-200";
      case "alert":
        return "bg-orange-50 border-orange-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return "الآن";
    if (minutes < 60) return `منذ ${minutes} دقيقة`;
    if (hours < 24) return `منذ ${hours} ساعة`;
    if (days < 7) return `منذ ${days} يوم`;
    return date.toLocaleDateString("ar-SA");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4 md:p-8 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="relative">
              <Bell className="w-8 h-8 text-blue-600" />
              {unreadCount > 0 && (
                <Badge className="absolute -top-2 -right-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs">
                  {unreadCount}
                </Badge>
              )}
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-800">مركز الإشعارات</h1>
              <p className="text-gray-600 text-sm">
                {unreadCount > 0
                  ? `لديك ${unreadCount} إشعار جديد`
                  : "جميع الإشعارات مقروءة"}
              </p>
            </div>
          </div>
          <Button
            onClick={() => setShowSettings(!showSettings)}
            variant="outline"
            size="sm"
          >
            <Settings className="w-4 h-4 ml-2" />
            الإعدادات
          </Button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 md:p-8">
        {/* Settings Panel */}
        {showSettings && (
          <Card className="p-6 mb-6 bg-blue-50 border-blue-200">
            <h3 className="text-lg font-bold text-gray-800 mb-4">إعدادات الإشعارات</h3>
            <div className="space-y-3">
              <label className="flex items-center gap-3">
                <input type="checkbox" defaultChecked className="w-4 h-4" />
                <span className="text-gray-700">إشعارات الحوادث</span>
              </label>
              <label className="flex items-center gap-3">
                <input type="checkbox" defaultChecked className="w-4 h-4" />
                <span className="text-gray-700">إشعارات الخدمات</span>
              </label>
              <label className="flex items-center gap-3">
                <input type="checkbox" defaultChecked className="w-4 h-4" />
                <span className="text-gray-700">إشعارات التحديثات</span>
              </label>
              <label className="flex items-center gap-3">
                <input type="checkbox" defaultChecked className="w-4 h-4" />
                <span className="text-gray-700">تنبيهات المرور</span>
              </label>
            </div>
          </Card>
        )}

        {/* Filter Buttons */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { value: "all" as const, label: "الكل" },
            { value: "unread" as const, label: `غير مقروء (${unreadCount})` },
            { value: "incident" as const, label: "الحوادث" },
            { value: "service" as const, label: "الخدمات" },
          ].map((btn) => (
            <Button
              key={btn.value}
              onClick={() => setFilter(btn.value)}
              variant={filter === btn.value ? "default" : "outline"}
              size="sm"
              className="whitespace-nowrap"
            >
              {btn.label}
            </Button>
          ))}
          {unreadCount > 0 && (
            <Button
              onClick={markAllAsRead}
              variant="outline"
              size="sm"
              className="ml-auto"
            >
              تحديد الكل كمقروء
            </Button>
          )}
        </div>

        {/* Notifications List */}
        <div className="space-y-4">
          {filteredNotifications.length > 0 ? (
            filteredNotifications.map((notification) => (
              <Card
                key={notification.id}
                className={`p-4 border-l-4 transition-all ${
                  getNotificationColor(notification.type)
                } ${!notification.read ? "border-l-blue-500 shadow-md" : "border-l-gray-300"}`}
              >
                <div className="flex items-start gap-4">
                  <div className="mt-1">
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-800">
                          {notification.title}
                        </h3>
                        <p className="text-gray-600 text-sm mt-1">
                          {notification.message}
                        </p>
                        <p className="text-gray-500 text-xs mt-2">
                          {formatTime(notification.timestamp)}
                        </p>
                      </div>
                      {!notification.read && (
                        <Badge className="bg-blue-500 text-white shrink-0">
                          جديد
                        </Badge>
                      )}
                    </div>
                    <div className="flex gap-2 mt-3">
                      {notification.actionUrl && (
                        <a href={notification.actionUrl}>
                          <Button size="sm" variant="outline" className="text-xs">
                            عرض التفاصيل
                          </Button>
                        </a>
                      )}
                      {!notification.read && (
                        <Button
                          onClick={() => markAsRead(notification.id)}
                          size="sm"
                          variant="outline"
                          className="text-xs"
                        >
                          وضع علامة كمقروء
                        </Button>
                      )}
                      <Button
                        onClick={() => deleteNotification(notification.id)}
                        size="sm"
                        variant="ghost"
                        className="text-xs text-red-600 hover:text-red-700"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="p-12 text-center">
              <Bell className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 text-lg">لا توجد إشعارات</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
