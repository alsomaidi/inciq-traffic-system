import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertTriangle,
  MapPin,
  Camera,
  CheckCircle,
  Clock,
  Zap,
  Phone,
  FileText,
  ArrowRight,
  Loader2,
} from "lucide-react";
import { InteractiveIcons } from "@/components/InteractiveIcons";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useCallback } from "react";
import { useLocation } from "wouter";

type IncidentStep = "initial" | "reporting" | "analyzing" | "result";

interface LocationState {
  pathname: string;
}

export default function INCIQApp() {
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState<IncidentStep>("initial");
  const [incidentType, setIncidentType] = useState<
    "injury" | "breakdown" | "traffic" | null
  >(null);
  // Removed duplicate setLocation - using locationValue instead
  const [description, setDescription] = useState("");
  const [latitude, setLatitude] = useState("");
  const [longitude, setLongitude] = useState("");
  const [reportedIncidentId, setReportedIncidentId] = useState<number | null>(
    null
  );
  const [locationValue, setLocationValue] = useState("");
  const [uploadedImages, setUploadedImages] = useState<File[]>([]);
  const [isAnalyzingImages, setIsAnalyzingImages] = useState(false);

  const utils = trpc.useUtils();
  const analyzeImagesMutation = trpc.incidents.analyzeImages.useMutation();
  const createIncidentMutation = trpc.incidents.create.useMutation({
    onSuccess: async () => {
      // إعادة تحميل قائمة الحوادث بعد إنشاء حادث جديد
      await utils.incidents.list.invalidate();
    },
  });

  const handleImageUpload = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = Array.from(e.target.files || []);
      if (files.length === 0) return;

      setUploadedImages((prev) => [...prev, ...files]);
      setIsAnalyzingImages(true);

      try {
        // تحويل الصور إلى base64 للإرسال
        const imagePromises = files.map(
          (file) =>
            new Promise<string>((resolve) => {
              const reader = new FileReader();
              reader.onload = () => resolve(reader.result as string);
              reader.readAsDataURL(file);
            })
        );

        const base64Images = await Promise.all(imagePromises);

        // تحليل الصور باستخدام AI
        const result = await analyzeImagesMutation.mutateAsync({
          images: base64Images,
          incidentType: incidentType || "breakdown",
        });

        // تعبئة البيانات المستخرجة
        if (result.extractedData) {
          if (result.extractedData.description) {
            setDescription(result.extractedData.description);
          }
          if (result.extractedData.damageLevel) {
            // يمكن استخدام هذه البيانات لاحقاً
          }
        }

        toast.success("تم تحليل الصور بنجاح");
      } catch (error) {
        console.error("Error analyzing images:", error);
        toast.error("حدث خطأ في تحليل الصور");
      } finally {
        setIsAnalyzingImages(false);
      }
    },
    [incidentType, analyzeImagesMutation]
  );
  const getIncidentQuery = trpc.incidents.list.useQuery({
    limit: 100,
  });

  // البحث عن الحادث المقدم
  const incident = reportedIncidentId && getIncidentQuery.data 
    ? getIncidentQuery.data.find((i) => i.id === reportedIncidentId)
    : null;

  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude.toString();
          const lon = position.coords.longitude.toString();
          setLatitude(lat);
          setLongitude(lon);
          setLocationValue("طريق الملك فهد - الرياض");
          toast.success("تم تحديد الموقع بنجاح");
        },
        () => {
          const fallbackLat = "24.7136";
          const fallbackLon = "46.6753";
          setLatitude(fallbackLat);
          setLongitude(fallbackLon);
          setLocationValue("طريق الملك فهد - الرياض");
          toast.success("تم تحديد الموقع بنجاح");
        }
      );
    }
  };

  const handleReportIncident = useCallback(async () => {
    if (!incidentType || !locationValue) {
      toast.error("الرجاء ملء جميع الحقول المطلوبة");
      return;
    }

    // إذا لم يتم تحديد الإحداثيات، استخدم القيم الافتراضية
    const finalLatitude = latitude || "24.7136";
    const finalLongitude = longitude || "46.6753";

    setCurrentStep("analyzing");

    try {
      const result = await createIncidentMutation.mutateAsync({
        incidentType: incidentType,
        location: locationValue,
        latitude: finalLatitude,
        longitude: finalLongitude,
        description,
      });

      setReportedIncidentId(result.id);
      toast.success("تم تقديم البلاغ بنجاح");

      // الانتظار 3 ثوانٍ ثم الانتقال إلى خطوة النتيجة
      await new Promise((resolve) => setTimeout(resolve, 3000));
      setCurrentStep("result");
    } catch (error) {
      console.error("Error submitting incident:", error);
      toast.error("حدث خطأ في تقديم البلاغ");
      setCurrentStep("reporting");
    }
  }, [incidentType, location, latitude, longitude, description, createIncidentMutation]);

  const incidentTypes = [
    {
      type: "injury" as const,
      label: "إصابات",
      icon: AlertTriangle,
      color: "text-red-400",
    },
    {
      type: "breakdown" as const,
      label: "تعطل سيارة",
      icon: Zap,
      color: "text-yellow-400",
    },
    {
      type: "traffic" as const,
      label: "تسيير",
      icon: Clock,
      color: "text-green-400",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f0f1e] via-[#1a1a2e] to-[#0f0f1e] text-white">
      {/* Header */}
      <header className="border-b border-white/10 backdrop-blur-md bg-white/5">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3 mb-4">
            <img src="/inciq-logo.png" alt="INCIQ" className="w-8 h-8" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              تطبيق تقديم البلاغات
            </h1>
          </div>
          <p className="text-gray-300">
            قدم بلاغ فوري عن الحادث واحصل على تقرير ذكي فوري
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-12">
        {/* Progress Indicator */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-4">
            {[
              { step: "initial", label: "البدء" },
              { step: "reporting", label: "التقرير" },
              { step: "analyzing", label: "التحليل" },
              { step: "result", label: "النتيجة" },
            ].map((item, i) => (
              <div key={item.step} className="flex items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                    currentStep === item.step
                      ? "bg-gradient-to-r from-cyan-400 to-blue-500 text-black scale-110"
                      : ["initial", "reporting", "analyzing", "result"].indexOf(
                          currentStep
                        ) > ["initial", "reporting", "analyzing", "result"].indexOf(
                          item.step
                        )
                      ? "bg-green-500 text-white"
                      : "bg-white/10 text-gray-400"
                  }`}
                >
                  {["initial", "reporting", "analyzing", "result"].indexOf(
                    currentStep
                  ) > ["initial", "reporting", "analyzing", "result"].indexOf(
                    item.step
                  ) ? (
                    <CheckCircle className="w-6 h-6" />
                  ) : (
                    i + 1
                  )}
                </div>
                {i < 3 && (
                  <div
                    className={`h-1 flex-1 mx-2 transition-all ${
                      ["initial", "reporting", "analyzing", "result"].indexOf(
                        currentStep
                      ) > i
                        ? "bg-green-500"
                        : "bg-white/10"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs text-gray-400">
            <span>البدء</span>
            <span>التقرير</span>
            <span>التحليل</span>
            <span>النتيجة</span>
          </div>
        </div>

        {/* Step Content */}
        {currentStep === "initial" && (
          <div className="space-y-6 animate-in fade-in duration-500">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-8 rounded-2xl">
              <h2 className="text-2xl font-bold mb-6">اختر نوع الحادث</h2>
              <div className="grid md:grid-cols-3 gap-4">
                {incidentTypes.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.type}
                      onClick={() => {
                        setIncidentType(item.type);
                        setCurrentStep("reporting");
                      }}
                      className={`p-6 rounded-xl border-2 transition-all transform hover:scale-105 ${
                        incidentType === item.type
                          ? "border-cyan-400 bg-cyan-400/10"
                          : "border-white/20 bg-white/5 hover:border-white/40"
                      }`}
                    >
                      <Icon className={`w-8 h-8 mb-3 mx-auto ${item.color}`} />
                      <p className="font-bold">{item.label}</p>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {currentStep === "reporting" && (
          <div className="space-y-6 animate-in fade-in duration-500">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-8 rounded-2xl">
              <h2 className="text-2xl font-bold mb-6">تفاصيل الحادث</h2>

              {/* Incident Type Badge */}
              <div className="mb-6">
                <Badge className="bg-cyan-500 text-black">
                  {incidentTypes.find((t) => t.type === incidentType)?.label}
                </Badge>
              </div>

              {/* Location Section */}
              <div className="mb-6">
                <label className="block text-sm font-bold mb-3">الموقع</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={locationValue}
                    onChange={(e) => setLocationValue(e.target.value)}
                    placeholder="الموقع الجغرافي"
                    className="flex-1 bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-cyan-400"
                  />
                  <Button
                    onClick={handleGetLocation}
                    className="bg-cyan-500 hover:bg-cyan-600 text-black font-bold"
                  >
                    <MapPin className="w-4 h-4 ml-2" />
                    تحديد
                  </Button>
                </div>
              </div>

              {/* Location Section */}
              <div className="mb-6">
                <label className="block text-sm font-bold mb-3">الموقع</label>
                <input
                  type="text"
                  value={locationValue}
                  onChange={(e) => setLocationValue(e.target.value)}
                  placeholder="مثال: طريق الملك فهد، تقاطع ..."
                  className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400"
                />
              </div>
              {/* Image Upload Section */}
              <div className="mb-6">
                <label className="block text-sm font-bold mb-3">رفع صور الحادث (اختياري)</label>
                <div className="border-2 border-dashed border-cyan-400/50 rounded-lg p-6 text-center hover:border-cyan-400 transition-colors cursor-pointer">
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageUpload}
                    disabled={isAnalyzingImages}
                    className="hidden"
                    id="image-upload"
                  />
                  <label htmlFor="image-upload" className="cursor-pointer block">
                    {isAnalyzingImages ? (
                      <>
                        <Loader2 className="w-8 h-8 mx-auto mb-2 text-cyan-400 animate-spin" />
                        <p className="text-cyan-400">جاري تحليل الصور...</p>
                      </>
                    ) : (
                      <>
                        <Camera className="w-8 h-8 mx-auto mb-2 text-cyan-400" />
                        <p className="text-gray-300">انقر لرفع الصور أو اسحبها</p>
                        <p className="text-xs text-gray-400 mt-1">سيتم تحليل الصور تلقائياً باستخدام الذكاء الاصطناعي</p>
                      </>
                    )}
                  </label>
                </div>
                {uploadedImages.length > 0 && (
                  <div className="mt-4">
                    <p className="text-sm text-gray-300 mb-2">الصور المرفوعة: {uploadedImages.length}</p>
                    <div className="flex flex-wrap gap-2">
                      {uploadedImages.map((img, idx) => (
                        <div key={idx} className="relative">
                          <img
                            src={URL.createObjectURL(img)}
                            alt={`Uploaded ${idx}`}
                            className="w-16 h-16 rounded-lg object-cover border border-cyan-400/50"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Coordinates */}
              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-bold mb-2">خط العرض</label>
                  <input
                    type="text"
                    value={latitude}
                    readOnly
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold mb-2">خط الطول</label>
                  <input
                    type="text"
                    value={longitude}
                    readOnly
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4">
                <Button
                  onClick={() => setCurrentStep("initial")}
                  variant="outline"
                  className="flex-1"
                >
                  رجوع
                </Button>
                <Button
                  onClick={handleReportIncident}
                  disabled={createIncidentMutation.isPending}
                  className="flex-1 bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-bold hover:shadow-lg hover:shadow-cyan-500/50"
                >
                  {createIncidentMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                      جاري التقديم...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 ml-2" />
                      تقديم البلاغ
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}

        {currentStep === "analyzing" && (
          <div className="space-y-6 animate-in fade-in duration-500">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-12 rounded-2xl text-center">
              <div className="mb-6">
                <div className="w-16 h-16 mx-auto bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex items-center justify-center animate-pulse">
                  <Camera className="w-8 h-8 text-black" />
                </div>
              </div>
              <h2 className="text-2xl font-bold mb-3">جاري تحليل الحادث...</h2>
              <p className="text-gray-300 mb-6">
                نقوم بتحليل الفيديو والأقمار الصناعية لتحديد نسبة الخطأ
              </p>
              <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                <div className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full w-2/3 animate-pulse" />
              </div>
            </div>
          </div>
        )}

        {currentStep === "result" && reportedIncidentId && (
          <div className="space-y-6 animate-in fade-in duration-500">
            {/* Smart Report */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-8 rounded-2xl">
              <div className="flex items-center gap-3 mb-6">
                <CheckCircle className="w-8 h-8 text-green-400" />
                <h2 className="text-2xl font-bold">التقرير الذكي</h2>
              </div>

              {/* Incident Details */}
              <div className="space-y-4 mb-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-white/5 p-4 rounded-lg">
                    <p className="text-gray-400 text-sm mb-1">نوع الحادث</p>
                    <p className="text-lg font-bold">
                      {incidentTypes.find((t) => t.type === incidentType)?.label}
                    </p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-lg">
                    <p className="text-gray-400 text-sm mb-1">الموقع</p>
                    <p className="text-lg font-bold">{locationValue}</p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-lg">
                    <p className="text-gray-400 text-sm mb-1">الحالة</p>
                    <Badge className="bg-green-500 text-white">
                      قيد المعالجة
                    </Badge>
                  </div>
                  <div className="bg-white/5 p-4 rounded-lg">
                    <p className="text-gray-400 text-sm mb-1">نسبة الخطأ</p>
                    <p className="text-lg font-bold text-cyan-400">
                      {Math.floor(Math.random() * 100)}%
                    </p>
                  </div>
                </div>
              </div>

              {/* Video Simulation */}
              <div className="mb-6">
                <p className="text-sm font-bold mb-3">محاكاة الفيديو الجوي</p>
                <div className="bg-black/50 rounded-lg p-8 text-center">
                  <Camera className="w-12 h-12 mx-auto text-gray-500 mb-3" />
                  <p className="text-gray-400">فيديو من الأقمار الصناعية</p>
                </div>
              </div>

              {/* Services Assigned */}
              <div className="mb-6">
                <p className="text-sm font-bold mb-3">الخدمات المطلوبة</p>
                <div className="grid md:grid-cols-2 gap-3">
                  {[
                    { name: "المرور", icon: Phone },
                    { name: "الهلال الأحمر", icon: AlertTriangle },
                    { name: "نجم", icon: Zap },
                    { name: "السطحة", icon: FileText },
                  ].map((service) => {
                    const Icon = service.icon;
                    return (
                      <div
                        key={service.name}
                        className="bg-white/5 border border-white/20 p-3 rounded-lg flex items-center gap-3"
                      >
                        <Icon className="w-5 h-5 text-cyan-400" />
                        <span>{service.name}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Interactive Icons */}
              {reportedIncidentId && (
                <div className="mt-8 pt-8 border-t border-white/20">
                  <h3 className="text-lg font-bold mb-6">الإجراءات السريعة</h3>
                  <InteractiveIcons
                    incidentId={reportedIncidentId || undefined}
                    onReportSubmit={() => {
                      toast.success("✅ تم تقديم البلاغ بنجاح");
                    }}
                    onProcessing={() => {
                      toast.success("✅ تمت معالجة الحادث بنجاح");
                    }}
                    onRouting={() => {
                      toast.success("📍 تم توجيه الخدمات بنجاح");
                    }}
                    onSend={() => {
                      toast.success("📧 تم إرسال التنبيهات بنجاح");
                    }}
                    onTracking={() => {
                      toast.success("🗺️ تم فتح خريطة التتبع");
                    }}
                    onRating={() => {
                      toast.success("⭐ شكراً لتقييمك");
                    }}
                  />
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-4 mt-8 flex-wrap">
                <Button
                  onClick={() => {
                    // Navigate to full report page with incident ID
                    if (reportedIncidentId) {
                      setLocation(`/smart-report?id=${reportedIncidentId}`);
                    } else {
                      toast.error("لم يتم العثور على معرف الحادث");
                    }
                  }}
                  className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-black font-bold flex-1"
                >
                  عرض التقرير الكامل
                </Button>
                <Button
                  onClick={() => {
                    // Reset form
                    setCurrentStep("initial");
                    setIncidentType(null);
                    setLocationValue("");
                    setDescription("");
                    setLatitude("");
                    setLongitude("");
                    setReportedIncidentId(null);
                  }}
                  variant="outline"
                  className="flex-1"
                >
                  <ArrowRight className="w-4 h-4 ml-2" />
                  تقديم بلاغ جديد
                </Button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
