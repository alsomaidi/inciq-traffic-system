import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Bell,
  AlertTriangle,
  Zap,
  Clock,
  MapPin,
  Smartphone,
  Settings,
  CheckCircle,
  Volume2,
  Eye,
} from "lucide-react";
import { toast } from "sonner";

interface SmartAlert {
  id: number;
  type: "proximity" | "speed" | "delay" | "hazard" | "congestion";
  title: string;
  message: string;
  severity: "low" | "medium" | "high" | "critical";
  timestamp: Date;
  incidentId: number;
  location: string;
  actionRequired: boolean;
  read: boolean;
  soundEnabled: boolean;
}

export default function SmartAlerts() {
  const [alerts, setAlerts] = useState<SmartAlert[]>([
    {
      id: 1,
      type: "proximity",
      title: "الإسعاف اقترب من الموقع",
      message: "إسعاف رقم 45 على بعد 500 متر من موقع الحادث - ETA 1 دقيقة",
      severity: "high",
      timestamp: new Date(Date.now() - 2 * 60000),
      incidentId: 1234,
      location: "طريق الملك فهد",
      actionRequired: true,
      read: false,
      soundEnabled: true,
    },
    {
      id: 2,
      type: "speed",
      title: "تحذير سرعة عالية",
      message: "سيارة تسير بسرعة 120 كم/س في منطقة الحادث - خطر!",
      severity: "critical",
      timestamp: new Date(Date.now() - 5 * 60000),
      incidentId: 1234,
      location: "طريق الملك فهد",
      actionRequired: true,
      read: false,
      soundEnabled: true,
    },
    {
      id: 3,
      type: "delay",
      title: "تأخر في الاستجابة",
      message: "السطحة تأخرت 2 دقيقة عن الموعد المتوقع",
      severity: "medium",
      timestamp: new Date(Date.now() - 10 * 60000),
      incidentId: 1234,
      location: "طريق الملك فهد",
      actionRequired: false,
      read: true,
      soundEnabled: false,
    },
    {
      id: 4,
      type: "congestion",
      title: "ازدحام متزايد",
      message: "الازدحام يتزايد بسرعة - 500 سيارة معطلة في المنطقة",
      severity: "high",
      timestamp: new Date(Date.now() - 15 * 60000),
      incidentId: 1234,
      location: "طريق الملك فهد",
      actionRequired: true,
      read: true,
      soundEnabled: false,
    },
    {
      id: 5,
      type: "hazard",
      title: "خطر على الطريق",
      message: "حطام السيارة على الحارة اليسرى - يعيق حركة المرور",
      severity: "high",
      timestamp: new Date(Date.now() - 20 * 60000),
      incidentId: 1234,
      location: "طريق الملك فهد",
      actionRequired: true,
      read: true,
      soundEnabled: false,
    },
  ]);

  const [filter, setFilter] = useState<"all" | "unread" | "critical" | "action">(
    "all"
  );
  const [showSettings, setShowSettings] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const unreadCount = alerts.filter((a) => !a.read).length;
  const criticalCount = alerts.filter((a) => a.severity === "critical").length;

  const filteredAlerts = alerts.filter((alert) => {
    if (filter === "unread") return !alert.read;
    if (filter === "critical") return alert.severity === "critical";
    if (filter === "action") return alert.actionRequired;
    return true;
  });

  const markAsRead = (id: number) => {
    setAlerts(alerts.map((a) => (a.id === id ? { ...a, read: true } : a)));
  };

  const dismissAlert = (id: number) => {
    setAlerts(alerts.filter((a) => a.id !== id));
    toast.success("تم إغلاق التنبيه");
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "proximity":
        return <MapPin className="w-6 h-6 text-blue-500" />;
      case "speed":
        return <Zap className="w-6 h-6 text-red-500" />;
      case "delay":
        return <Clock className="w-6 h-6 text-orange-500" />;
      case "hazard":
        return <AlertTriangle className="w-6 h-6 text-red-600" />;
      case "congestion":
        return <AlertTriangle className="w-6 h-6 text-yellow-500" />;
      default:
        return <Bell className="w-6 h-6 text-gray-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-100 border-red-300 text-red-900";
      case "high":
        return "bg-orange-100 border-orange-300 text-orange-900";
      case "medium":
        return "bg-yellow-100 border-yellow-300 text-yellow-900";
      case "low":
        return "bg-green-100 border-green-300 text-green-900";
      default:
        return "bg-gray-100 border-gray-300 text-gray-900";
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case "critical":
        return <Badge className="bg-red-600 text-white">حرج جداً</Badge>;
      case "high":
        return <Badge className="bg-orange-600 text-white">عالي</Badge>;
      case "medium":
        return <Badge className="bg-yellow-600 text-white">متوسط</Badge>;
      case "low":
        return <Badge className="bg-green-600 text-white">منخفض</Badge>;
      default:
        return <Badge>غير محدد</Badge>;
    }
  };

  const getAlertTypeAr = (type: string) => {
    switch (type) {
      case "proximity":
        return "اقتراب الخدمة";
      case "speed":
        return "تحذير السرعة";
      case "delay":
        return "التأخر";
      case "hazard":
        return "خطر على الطريق";
      case "congestion":
        return "الازدحام";
      default:
        return "تنبيه";
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);

    if (minutes < 1) return "الآن";
    if (minutes < 60) return `منذ ${minutes} دقيقة`;
    if (hours < 24) return `منذ ${hours} ساعة`;
    return date.toLocaleDateString("ar-SA");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4 md:p-8 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="relative">
                <Smartphone className="w-8 h-8 text-blue-600" />
                {criticalCount > 0 && (
                  <div className="absolute -top-2 -right-2 w-5 h-5 bg-red-600 text-white rounded-full flex items-center justify-center text-xs font-bold animate-pulse">
                    {criticalCount}
                  </div>
                )}
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">
                  التنبيهات الذكية
                </h1>
                <p className="text-gray-600 text-sm">
                  {criticalCount > 0
                    ? `⚠️ ${criticalCount} تنبيهات حرجة تتطلب انتباهك`
                    : "جميع التنبيهات تحت السيطرة"}
                </p>
              </div>
            </div>
            <Button
              onClick={() => setShowSettings(!showSettings)}
              variant="outline"
              size="sm"
            >
              <Settings className="w-4 h-4 ml-2" />
              الإعدادات
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 md:p-8">
        {/* Settings Panel */}
        {showSettings && (
          <Card className="p-6 mb-6 bg-blue-50 border-blue-200">
            <h3 className="text-lg font-bold text-gray-800 mb-4">
              إعدادات التنبيهات
            </h3>
            <div className="space-y-4">
              <label className="flex items-center gap-3 p-3 bg-white rounded-lg border border-gray-200">
                <input
                  type="checkbox"
                  checked={notificationsEnabled}
                  onChange={(e) => setNotificationsEnabled(e.target.checked)}
                  className="w-4 h-4"
                />
                <span className="text-gray-700 font-medium">
                  تفعيل جميع التنبيهات
                </span>
              </label>
              <label className="flex items-center gap-3 p-3 bg-white rounded-lg border border-gray-200">
                <input
                  type="checkbox"
                  checked={soundEnabled}
                  onChange={(e) => setSoundEnabled(e.target.checked)}
                  className="w-4 h-4"
                />
                <span className="text-gray-700 font-medium">
                  تفعيل الأصوات التنبيهية
                </span>
              </label>
              <div className="p-3 bg-white rounded-lg border border-gray-200">
                <p className="text-sm text-gray-700 font-medium mb-2">
                  مستوى الخطورة المطلوب التنبيه عنه:
                </p>
                <div className="space-y-2">
                  {["critical", "high", "medium", "low"].map((level) => (
                    <label key={level} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        defaultChecked
                        className="w-3 h-3"
                      />
                      <span className="text-sm text-gray-600">
                        {level === "critical"
                          ? "حرج جداً"
                          : level === "high"
                          ? "عالي"
                          : level === "medium"
                          ? "متوسط"
                          : "منخفض"}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Filter Buttons */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { value: "all" as const, label: "الكل" },
            { value: "unread" as const, label: `جديد (${unreadCount})` },
            { value: "critical" as const, label: `حرج (${criticalCount})` },
            { value: "action" as const, label: "يتطلب إجراء" },
          ].map((btn) => (
            <Button
              key={btn.value}
              onClick={() => setFilter(btn.value)}
              variant={filter === btn.value ? "default" : "outline"}
              size="sm"
              className="whitespace-nowrap"
            >
              {btn.label}
            </Button>
          ))}
        </div>

        {/* Alerts List */}
        <div className="space-y-4">
          {filteredAlerts.length > 0 ? (
            filteredAlerts.map((alert) => (
              <Card
                key={alert.id}
                className={`p-6 border-l-4 transition-all ${getSeverityColor(
                  alert.severity
                )} ${!alert.read ? "shadow-lg" : ""}`}
              >
                <div className="flex items-start gap-4">
                  <div className="mt-1">{getAlertIcon(alert.type)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex-1">
                        <h3 className="font-bold text-lg">{alert.title}</h3>
                        <p className="text-sm opacity-75 mt-1">
                          {alert.message}
                        </p>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        {getSeverityBadge(alert.severity)}
                        {!alert.read && (
                          <Badge className="bg-blue-600 text-white">جديد</Badge>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-4 mt-3 text-sm opacity-75">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {alert.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {formatTime(alert.timestamp)}
                      </span>
                      <span className="flex items-center gap-1">
                        <span>الحادث #{alert.incidentId}</span>
                      </span>
                    </div>

                    <div className="flex gap-2 mt-4">
                      {alert.actionRequired && (
                        <div className="flex-1 bg-red-200 bg-opacity-50 rounded-lg p-2 text-sm font-medium">
                          ⚠️ يتطلب إجراء فوري
                        </div>
                      )}
                      {!alert.read && (
                        <Button
                          onClick={() => markAsRead(alert.id)}
                          size="sm"
                          variant="outline"
                          className="text-xs"
                        >
                          <Eye className="w-3 h-3 ml-1" />
                          وضع علامة كمقروء
                        </Button>
                      )}
                      <Button
                        onClick={() => dismissAlert(alert.id)}
                        size="sm"
                        variant="ghost"
                        className="text-xs text-red-600 hover:text-red-700"
                      >
                        إغلاق
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="p-12 text-center">
              <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
              <p className="text-gray-600 text-lg">لا توجد تنبيهات</p>
              <p className="text-gray-500 text-sm mt-2">
                جميع الأمور تحت السيطرة بنجاح
              </p>
            </Card>
          )}
        </div>

        {/* Alert Statistics */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            {
              label: "تنبيهات حرجة",
              value: criticalCount,
              color: "bg-red-100 text-red-700",
            },
            {
              label: "تنبيهات عالية",
              value: alerts.filter((a) => a.severity === "high").length,
              color: "bg-orange-100 text-orange-700",
            },
            {
              label: "غير مقروءة",
              value: unreadCount,
              color: "bg-blue-100 text-blue-700",
            },
            {
              label: "تتطلب إجراء",
              value: alerts.filter((a) => a.actionRequired).length,
              color: "bg-yellow-100 text-yellow-700",
            },
          ].map((stat, index) => (
            <Card key={index} className={`p-4 text-center ${stat.color}`}>
              <p className="text-3xl font-bold">{stat.value}</p>
              <p className="text-sm font-medium">{stat.label}</p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
