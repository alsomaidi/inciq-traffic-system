import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertTriangle,
  Clock,
  CheckCircle,
  MapPin,
  Phone,
  Zap,
  Filter,
  MoreVertical,
  TrendingUp,
  RefreshCw,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";

export default function OperatorDashboard() {
  const { user } = useAuth();
  const [selectedIncident, setSelectedIncident] = useState<number | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [refreshing, setRefreshing] = useState(false);

  const { data: incidents, refetch } = trpc.incidents.list.useQuery({ limit: 50 });
  const updateStatusMutation = trpc.incidents.updateStatus.useMutation();

  // التحقق من الصلاحيات
  if (user?.role === "user") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0f0f1e] via-[#1a1a2e] to-[#0f0f1e] text-white flex items-center justify-center">
        <div className="bg-white/10 backdrop-blur-md border border-white/20 p-8 rounded-2xl text-center max-w-md">
          <AlertTriangle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">غير مصرح بالوصول</h2>
          <p className="text-gray-300">
            هذه الصفحة مخصصة لمشغلي مركز التحكم والإداريين فقط
          </p>
        </div>
      </div>
    );
  }

  const filteredIncidents = incidents?.filter((incident) => {
    if (filterStatus === "all") return true;
    return incident.status === filterStatus;
  });

  const stats = {
    total: incidents?.length || 0,
    pending: incidents?.filter((i) => i.status === "pending").length || 0,
    inProgress: incidents?.filter((i) => i.status === "in_progress").length || 0,
    resolved: incidents?.filter((i) => i.status === "resolved").length || 0,
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
    toast.success("تم تحديث البيانات");
  };

  const handleStatusUpdate = async (incidentId: number, newStatus: string) => {
    try {
      await updateStatusMutation.mutateAsync({
        id: incidentId,
        status: newStatus as any,
      });
      refetch();
      toast.success("تم تحديث حالة الحادث");
    } catch (error) {
      toast.error("حدث خطأ في تحديث الحالة");
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/50";
      case "assigned":
        return "bg-blue-500/20 text-blue-400 border-blue-500/50";
      case "in_progress":
        return "bg-cyan-500/20 text-cyan-400 border-cyan-500/50";
      case "resolved":
        return "bg-green-500/20 text-green-400 border-green-500/50";
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/50";
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: { [key: string]: string } = {
      pending: "قيد الانتظار",
      assigned: "مُسند",
      in_progress: "قيد المعالجة",
      resolved: "تم حله",
      closed: "مُغلق",
    };
    return labels[status] || status;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f0f1e] via-[#1a1a2e] to-[#0f0f1e] text-white">
      {/* Header */}
      <header className="border-b border-white/10 backdrop-blur-md bg-white/5">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                لوحة تحكم مركز العمليات
              </h1>
              <p className="text-gray-300 mt-2">إدارة وتتبع جميع الحوادث المرورية</p>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={handleRefresh}
                disabled={refreshing}
                className="bg-white/10 hover:bg-white/20"
              >
                <RefreshCw className={`w-4 h-4 ml-2 ${refreshing ? "animate-spin" : ""}`} />
                تحديث
              </Button>
              <img src="/inciq-logo.png" alt="INCIQ" className="w-12 h-12" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Statistics */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "إجمالي الحوادث", value: stats.total, icon: AlertTriangle, color: "from-red-500 to-orange-500" },
            { label: "قيد الانتظار", value: stats.pending, icon: Clock, color: "from-yellow-500 to-orange-500" },
            { label: "قيد المعالجة", value: stats.inProgress, icon: Zap, color: "from-cyan-500 to-blue-500" },
            { label: "تم حله", value: stats.resolved, icon: CheckCircle, color: "from-green-500 to-emerald-500" },
          ].map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div
                key={i}
                className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-xl hover:border-white/40 transition-all group"
              >
                <div className="flex items-center justify-between mb-4">
                  <p className="text-gray-300 text-sm">{stat.label}</p>
                  <div className={`bg-gradient-to-br ${stat.color} p-3 rounded-lg group-hover:scale-110 transition-transform`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                </div>
                <p className="text-3xl font-bold">{stat.value}</p>
                <p className="text-xs text-gray-400 mt-2">
                  <TrendingUp className="w-3 h-3 inline mr-1" />
                  آخر 24 ساعة
                </p>
              </div>
            );
          })}
        </div>

        {/* Filter and Controls */}
        <div className="mb-6 flex gap-3 flex-wrap">
          <Button
            onClick={() => setFilterStatus("all")}
            className={`${
              filterStatus === "all"
                ? "bg-gradient-to-r from-cyan-400 to-blue-500 text-black"
                : "bg-white/10 hover:bg-white/20"
            }`}
          >
            <Filter className="w-4 h-4 ml-2" />
            الكل
          </Button>
          {["pending", "assigned", "in_progress", "resolved"].map((status) => (
            <Button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={
                filterStatus === status
                  ? "bg-cyan-500 text-black"
                  : "bg-white/10 hover:bg-white/20"
              }
            >
              {getStatusLabel(status)}
            </Button>
          ))}
        </div>

        {/* Incidents List */}
        <div className="space-y-4">
          {filteredIncidents?.map((incident) => (
            <div
              key={incident.id}
              className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-xl hover:border-white/40 transition-all cursor-pointer group"
              onClick={() => setSelectedIncident(selectedIncident === incident.id ? null : incident.id)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <Badge className={`${getStatusColor(incident.status)} border`}>
                      {getStatusLabel(incident.status)}
                    </Badge>
                    <span className="text-sm text-gray-400">#{incident.id}</span>
                  </div>
                  <h3 className="text-lg font-bold mb-2">{incident.location}</h3>
                  <p className="text-gray-300 text-sm mb-3">{incident.description || "بدون وصف"}</p>
                </div>
                <MoreVertical className="w-5 h-5 text-gray-400 group-hover:text-cyan-400 transition-colors" />
              </div>

              {/* Incident Details */}
              <div className="grid md:grid-cols-3 gap-4 mb-4 pb-4 border-b border-white/10">
                <div>
                  <p className="text-xs text-gray-400 mb-1">الموقع</p>
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-cyan-400" />
                    {incident.location}
                  </div>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-1">الإحداثيات</p>
                  <p className="text-sm">{incident.latitude}, {incident.longitude}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-1">الوقت</p>
                  <p className="text-sm">
                    {new Date(incident.createdAt).toLocaleTimeString("ar-SA")}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              {selectedIncident === incident.id && (
                <div className="space-y-3 pt-4 border-t border-white/10 animate-in fade-in duration-300">
                  <div className="grid md:grid-cols-2 gap-3">
                    {["assigned", "in_progress", "resolved", "closed"].map((status) => (
                      <Button
                        key={status}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleStatusUpdate(incident.id, status);
                        }}
                        disabled={updateStatusMutation.isPending}
                        className="bg-white/10 hover:bg-white/20 text-sm"
                      >
                        {getStatusLabel(status)}
                      </Button>
                    ))}
                  </div>
                  <div className="grid md:grid-cols-2 gap-3">
                    <Button className="bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-bold">
                      <Phone className="w-4 h-4 ml-2" />
                      اتصال فوري
                    </Button>
                    <Button className="bg-white/10 hover:bg-white/20">
                      <MapPin className="w-4 h-4 ml-2" />
                      عرض على الخريطة
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ))}

          {filteredIncidents?.length === 0 && (
            <div className="text-center py-12">
              <AlertTriangle className="w-12 h-12 mx-auto text-gray-500 mb-4" />
              <p className="text-gray-400">لا توجد حوادث بهذه الحالة</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
