import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Star,
  MessageSquare,
  X,
} from "lucide-react";
import { toast } from "sonner";

interface Feedback {
  id: number;
  incidentId: number;
  rating: number;
  category: string;
  comment: string;
  timestamp: Date;
  status: "pending" | "reviewed" | "resolved";
}

export default function FeedbackSystem() {
  const [feedbackList] = useState<Feedback[]>([
    {
      id: 1,
      incidentId: 1234,
      rating: 5,
      category: "سرعة الاستجابة",
      comment: "استجابة سريعة جداً من الفريق",
      timestamp: new Date(Date.now() - 2 * 3600000),
      status: "reviewed",
    },
    {
      id: 2,
      incidentId: 1233,
      rating: 4,
      category: "احترافية الفريق",
      comment: "فريق احترافي وودود",
      timestamp: new Date(Date.now() - 1 * 86400000),
      status: "resolved",
    },
    {
      id: 3,
      incidentId: 1232,
      rating: 3,
      category: "وضوح التواصل",
      comment: "كان يمكن تحسين التواصل",
      timestamp: new Date(Date.now() - 3 * 86400000),
      status: "pending",
    },
  ]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge className="bg-cyan-500 text-white">تحت المراجعة</Badge>;
      case "reviewed":
        return <Badge className="bg-blue-500 text-white">تم الحل</Badge>;
      case "resolved":
        return <Badge className="bg-green-500 text-white">تم الحل</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (hours < 24) return `منذ ${hours} ساعة`;
    return `منذ ${days} يوم`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-6xl mx-auto p-4 md:p-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-2">
            <MessageSquare className="w-8 h-8 text-cyan-600" />
            <h1 className="text-3xl font-bold text-gray-800">أحدث التقييمات</h1>
          </div>
          <div className="flex gap-2 mt-4">
            <Button className="bg-white text-gray-700 border border-gray-300 hover:bg-gray-50">
              الكل
            </Button>
            <Button variant="ghost" className="text-gray-600">
              <X className="w-4 h-4 ml-2" />
              تحت المراجعة
            </Button>
          </div>
        </div>

        {/* Feedback List */}
        <div className="space-y-6">
          {feedbackList.map((feedback) => (
            <Card
              key={feedback.id}
              className="p-6 bg-gray-900 text-white border-gray-700 shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-5 h-5 ${
                            star <= feedback.rating
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-600"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-400">
                      {feedback.rating}/5
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-white mb-1">
                    الحادث #{feedback.incidentId}
                  </h3>
                  <p className="text-sm text-gray-400 mb-3">
                    {feedback.category}
                  </p>
                </div>
                {getStatusBadge(feedback.status)}
              </div>

              <div className="bg-gray-800 rounded-lg p-4 mb-4">
                <p className="text-gray-300 text-sm leading-relaxed">
                  {feedback.comment}
                </p>
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-400">
                  {formatTime(feedback.timestamp)}
                </span>
                <Button
                  size="sm"
                  variant="ghost"
                  className="text-cyan-400 hover:text-cyan-300 hover:bg-gray-800"
                >
                  عرض التفاصيل
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {/* Empty State for Demo */}
        <div className="mt-8 text-center">
          <p className="text-gray-600">
            يتم عرض آخر التقييمات المستلمة
          </p>
        </div>
      </div>
    </div>
  );
}
