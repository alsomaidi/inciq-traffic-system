export interface ReportData {
  id: string;
  type: string;
  location: string;
  coordinates: { lat: number; lng: number };
  timestamp: number;
  errorRate: number;
  requiredServices: string[];
  repairSheet: RepairItem[];
  recommendations: string[];
  notes: string;
}

export interface RepairItem {
  id: string;
  title: string;
  severity: "low" | "medium" | "high";
  description: string;
  estimatedCost: number;
  estimatedTime: string;
}

export const exportReportToPDF = async (report: ReportData) => {
  try {
    const textContent = generateTextReport(report);
    downloadAsFile(textContent, `report-${report.id}.txt`, "text/plain");
    return true;
  } catch (error) {
    console.error("Error exporting PDF:", error);
    return false;
  }
};

const generateTextReport = (report: ReportData): string => {
  const totalCost = report.repairSheet.reduce(
    (sum, item) => sum + item.estimatedCost,
    0
  );

  return `
INCIQ - نظام معالجة الحوادث المرورية
تقرير الحادث الذكي
=====================================

معلومات الحادث:
- رقم البلاغ: ${report.id}
- نوع الحادث: ${report.type}
- الموقع: ${report.location}
- الإحداثيات: ${report.coordinates.lat}, ${report.coordinates.lng}
- الوقت: ${new Date(report.timestamp).toLocaleString("ar-SA")}

نسبة الخطأ: ${report.errorRate}%
دقة التحليل: ${100 - report.errorRate}%

الخدمات المطلوبة:
${report.requiredServices.map((s) => `- ${s}`).join("\n")}

ورقة الإصلاح:
${report.repairSheet
  .map(
    (item) => `
${item.title}
- الخطورة: ${item.severity}
- الوصف: ${item.description}
- التكلفة المتوقعة: ${item.estimatedCost} ريال
- الوقت المتوقع: ${item.estimatedTime}
`
  )
  .join("\n")}

إجمالي التكلفة المتوقعة: ${totalCost} ريال

التوصيات:
${report.recommendations.map((r) => `- ${r}`).join("\n")}

ملاحظات:
${report.notes}
  `;
};

const downloadAsFile = (
  content: string,
  filename: string,
  mimeType: string
) => {
  const element = document.createElement("a");
  const file = new Blob([content], { type: mimeType });
  element.href = URL.createObjectURL(file);
  element.download = filename;
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);
  URL.revokeObjectURL(element.href);
};

export const printReport = (report: ReportData) => {
  const htmlContent = generateHTMLReport(report);
  const printWindow = window.open("", "", "width=800,height=600");
  
  if (printWindow) {
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.print();
  }
};

const generateHTMLReport = (report: ReportData): string => {
  const totalCost = report.repairSheet.reduce(
    (sum, item) => sum + item.estimatedCost,
    0
  );

  return `
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="UTF-8">
      <title>تقرير الحادث ${report.id}</title>
      <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 40px; }
        .header { text-align: center; border-bottom: 3px solid #00bcd4; padding-bottom: 20px; margin-bottom: 30px; }
        .header h1 { color: #333; font-size: 28px; }
        .section { margin-bottom: 30px; }
        .section h2 { color: #00bcd4; font-size: 18px; border-bottom: 2px solid #e0e0e0; padding-bottom: 10px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>تقرير الحادث الذكي</h1>
          <p>نظام INCIQ لمعالجة الحوادث المرورية</p>
        </div>
        <div class="section">
          <h2>معلومات الحادث</h2>
          <p>رقم البلاغ: ${report.id}</p>
          <p>نوع الحادث: ${report.type}</p>
          <p>الموقع: ${report.location}</p>
          <p>نسبة الخطأ: ${report.errorRate}%</p>
        </div>
      </div>
    </body>
    </html>
  `;
};
