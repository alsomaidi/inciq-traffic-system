import React, { useState } from "react";
import {
  AlertCircle,
  CheckCircle,
  Navigation,
  Send,
  MapPin,
  Star,
  Loader,
} from "lucide-react";
import { toast } from "sonner";

/**
 * مكون الأيقونات التفاعلية المفعلة
 * يتضمن جميع الأيقونات الرئيسية مع وظائفها الفعلية
 */

interface InteractiveIconsProps {
  incidentId?: number;
  onReportSubmit?: () => void;
  onProcessing?: () => void;
  onRouting?: () => void;
  onSend?: () => void;
  onTracking?: () => void;
  onRating?: () => void;
}

export const InteractiveIcons: React.FC<InteractiveIconsProps> = ({
  incidentId,
  onReportSubmit,
  onProcessing,
  onRouting,
  onSend,
  onTracking,
  onRating,
}) => {
  const [loading, setLoading] = useState<string | null>(null);

  const handleReportSubmit = async () => {
    setLoading("report");
    try {
      toast.success("✅ تم تقديم البلاغ بنجاح");
      onReportSubmit?.();
    } catch (error) {
      toast.error("❌ خطأ في تقديم البلاغ");
    } finally {
      setLoading(null);
    }
  };

  const handleProcessing = async () => {
    setLoading("processing");
    try {
      toast.loading("🔄 جاري معالجة الحادث...");
      // محاكاة المعالجة
      await new Promise((resolve) => setTimeout(resolve, 3000));
      toast.success("✅ تمت معالجة الحادث بنجاح");
      onProcessing?.();
    } catch (error) {
      toast.error("❌ خطأ في معالجة الحادث");
    } finally {
      setLoading(null);
    }
  };

  const handleRouting = async () => {
    setLoading("routing");
    try {
      toast.success("📍 تم توجيه الخدمات بنجاح");
      onRouting?.();
    } catch (error) {
      toast.error("❌ خطأ في توجيه الخدمات");
    } finally {
      setLoading(null);
    }
  };

  const handleSend = async () => {
    setLoading("send");
    try {
      toast.success("📧 تم إرسال التنبيهات بنجاح");
      onSend?.();
    } catch (error) {
      toast.error("❌ خطأ في إرسال التنبيهات");
    } finally {
      setLoading(null);
    }
  };

  const handleTracking = async () => {
    setLoading("tracking");
    try {
      toast.success("🗺️ تم فتح خريطة التتبع");
      onTracking?.();
    } catch (error) {
      toast.error("❌ خطأ في فتح الخريطة");
    } finally {
      setLoading(null);
    }
  };

  const handleRating = async () => {
    setLoading("rating");
    try {
      toast.success("⭐ شكراً لتقييمك");
      onRating?.();
    } catch (error) {
      toast.error("❌ خطأ في التقييم");
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {/* أيقونة تقديم البلاغ */}
      <button
        onClick={handleReportSubmit}
        disabled={loading === "report"}
        className="group relative flex flex-col items-center justify-center p-4 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 hover:border-cyan-400 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/20"
        title="تقديم البلاغ"
      >
        {loading === "report" ? (
          <Loader className="w-6 h-6 text-cyan-400 animate-spin" />
        ) : (
          <AlertCircle className="w-6 h-6 text-cyan-400 group-hover:text-cyan-300 transition-colors" />
        )}
        <span className="text-xs mt-2 text-cyan-300 group-hover:text-cyan-200">
          البلاغ
        </span>
      </button>

      {/* أيقونة المعالجة */}
      <button
        onClick={handleProcessing}
        disabled={loading === "processing"}
        className="group relative flex flex-col items-center justify-center p-4 rounded-lg bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 hover:border-blue-400 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/20"
        title="معالجة الحادث"
      >
        {loading === "processing" ? (
          <Loader className="w-6 h-6 text-blue-400 animate-spin" />
        ) : (
          <CheckCircle className="w-6 h-6 text-blue-400 group-hover:text-blue-300 transition-colors" />
        )}
        <span className="text-xs mt-2 text-blue-300 group-hover:text-blue-200">
          المعالجة
        </span>
      </button>

      {/* أيقونة التوجيه */}
      <button
        onClick={handleRouting}
        disabled={loading === "routing"}
        className="group relative flex flex-col items-center justify-center p-4 rounded-lg bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30 hover:border-purple-400 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/20"
        title="توجيه الخدمات"
      >
        {loading === "routing" ? (
          <Loader className="w-6 h-6 text-purple-400 animate-spin" />
        ) : (
          <Navigation className="w-6 h-6 text-purple-400 group-hover:text-purple-300 transition-colors" />
        )}
        <span className="text-xs mt-2 text-purple-300 group-hover:text-purple-200">
          التوجيه
        </span>
      </button>

      {/* أيقونة الإرسال */}
      <button
        onClick={handleSend}
        disabled={loading === "send"}
        className="group relative flex flex-col items-center justify-center p-4 rounded-lg bg-gradient-to-br from-pink-500/20 to-red-500/20 border border-pink-500/30 hover:border-pink-400 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/20"
        title="إرسال التنبيهات"
      >
        {loading === "send" ? (
          <Loader className="w-6 h-6 text-pink-400 animate-spin" />
        ) : (
          <Send className="w-6 h-6 text-pink-400 group-hover:text-pink-300 transition-colors" />
        )}
        <span className="text-xs mt-2 text-pink-300 group-hover:text-pink-200">
          الإرسال
        </span>
      </button>

      {/* أيقونة التتبع */}
      <button
        onClick={handleTracking}
        disabled={loading === "tracking"}
        className="group relative flex flex-col items-center justify-center p-4 rounded-lg bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-green-500/30 hover:border-green-400 transition-all duration-300 hover:shadow-lg hover:shadow-green-500/20"
        title="تتبع الحادث"
      >
        {loading === "tracking" ? (
          <Loader className="w-6 h-6 text-green-400 animate-spin" />
        ) : (
          <MapPin className="w-6 h-6 text-green-400 group-hover:text-green-300 transition-colors" />
        )}
        <span className="text-xs mt-2 text-green-300 group-hover:text-green-200">
          التتبع
        </span>
      </button>

      {/* أيقونة التقييم */}
      <button
        onClick={handleRating}
        disabled={loading === "rating"}
        className="group relative flex flex-col items-center justify-center p-4 rounded-lg bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 hover:border-yellow-400 transition-all duration-300 hover:shadow-lg hover:shadow-yellow-500/20"
        title="تقييم الخدمة"
      >
        {loading === "rating" ? (
          <Loader className="w-6 h-6 text-yellow-400 animate-spin" />
        ) : (
          <Star className="w-6 h-6 text-yellow-400 group-hover:text-yellow-300 transition-colors" />
        )}
        <span className="text-xs mt-2 text-yellow-300 group-hover:text-yellow-200">
          التقييم
        </span>
      </button>
    </div>
  );
};

/**
 * مكون أيقونة واحدة قابلة للتخصيص
 */
export const InteractiveIcon: React.FC<{
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  loading?: boolean;
  color?: string;
  disabled?: boolean;
}> = ({ icon, label, onClick, loading = false, color = "cyan", disabled }) => {
  const colorClasses: { [key: string]: string } = {
    cyan: "from-cyan-500/20 to-blue-500/20 border-cyan-500/30 hover:border-cyan-400 hover:shadow-cyan-500/20 text-cyan-400 hover:text-cyan-300",
    blue: "from-blue-500/20 to-purple-500/20 border-blue-500/30 hover:border-blue-400 hover:shadow-blue-500/20 text-blue-400 hover:text-blue-300",
    purple:
      "from-purple-500/20 to-pink-500/20 border-purple-500/30 hover:border-purple-400 hover:shadow-purple-500/20 text-purple-400 hover:text-purple-300",
    pink: "from-pink-500/20 to-red-500/20 border-pink-500/30 hover:border-pink-400 hover:shadow-pink-500/20 text-pink-400 hover:text-pink-300",
    green:
      "from-green-500/20 to-emerald-500/20 border-green-500/30 hover:border-green-400 hover:shadow-green-500/20 text-green-400 hover:text-green-300",
    yellow:
      "from-yellow-500/20 to-orange-500/20 border-yellow-500/30 hover:border-yellow-400 hover:shadow-yellow-500/20 text-yellow-400 hover:text-yellow-300",
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className={`group relative flex flex-col items-center justify-center p-4 rounded-lg bg-gradient-to-br ${colorClasses[color]} border transition-all duration-300 hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed`}
      title={label}
    >
      {loading ? (
        <Loader className="w-6 h-6 animate-spin" />
      ) : (
        <div className="w-6 h-6 transition-colors">{icon}</div>
      )}
      <span className="text-xs mt-2 opacity-75 group-hover:opacity-100">
        {label}
      </span>
    </button>
  );
};
