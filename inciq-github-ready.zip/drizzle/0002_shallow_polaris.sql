CREATE TABLE `reportSends` (
	`id` int AUTO_INCREMENT NOT NULL,
	`incidentId` int NOT NULL,
	`recipientType` enum('party','insurance','najm','operator') NOT NULL,
	`recipientEmail` varchar(255) NOT NULL,
	`recipientPhone` varchar(20),
	`recipientName` varchar(255),
	`status` enum('pending','sent','failed','read') NOT NULL DEFAULT 'pending',
	`sentAt` timestamp,
	`readAt` timestamp,
	`failureReason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reportSends_id` PRIMARY KEY(`id`)
);
