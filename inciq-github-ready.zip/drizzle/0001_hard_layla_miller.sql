CREATE TABLE `incidentHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`incidentId` int NOT NULL,
	`action` varchar(255) NOT NULL,
	`details` text,
	`performedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `incidentHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `incidentMedia` (
	`id` int AUTO_INCREMENT NOT NULL,
	`incidentId` int NOT NULL,
	`mediaType` enum('image','video') NOT NULL,
	`mediaUrl` text NOT NULL,
	`description` text,
	`isSimulated` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `incidentMedia_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `incidentParties` (
	`id` int AUTO_INCREMENT NOT NULL,
	`incidentId` int NOT NULL,
	`partyName` varchar(255) NOT NULL,
	`phone` varchar(20),
	`vehicleNumber` varchar(50),
	`faultPercentage` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `incidentParties_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `incidents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reporterId` int NOT NULL,
	`incidentType` enum('injury','breakdown','traffic') NOT NULL,
	`location` text NOT NULL,
	`latitude` decimal(10,8) NOT NULL,
	`longitude` decimal(11,8) NOT NULL,
	`description` text,
	`status` enum('pending','assigned','in_progress','resolved','closed') NOT NULL DEFAULT 'pending',
	`severity` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium',
	`reportedAt` timestamp NOT NULL DEFAULT (now()),
	`resolvedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `incidents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `services` (
	`id` int AUTO_INCREMENT NOT NULL,
	`incidentId` int NOT NULL,
	`serviceType` enum('ambulance','tow_truck','traffic_control','police','fire') NOT NULL,
	`status` enum('pending','assigned','en_route','arrived','completed','cancelled') NOT NULL DEFAULT 'pending',
	`assignedTo` varchar(255),
	`estimatedArrivalTime` timestamp,
	`arrivedAt` timestamp,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `services_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `statistics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`date` timestamp NOT NULL DEFAULT (now()),
	`totalIncidents` int DEFAULT 0,
	`injuryIncidents` int DEFAULT 0,
	`breakdownIncidents` int DEFAULT 0,
	`trafficIncidents` int DEFAULT 0,
	`averageResolutionTime` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `statistics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','operator','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);