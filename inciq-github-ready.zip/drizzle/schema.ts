import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "operator", "admin"]).default("user").notNull(),
  phone: varchar("phone", { length: 20 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// جدول الحوادث المرورية
export const incidents = mysqlTable("incidents", {
  id: int("id").autoincrement().primaryKey(),
  reporterId: int("reporterId").notNull(),
  incidentType: mysqlEnum("incidentType", ["injury", "breakdown", "traffic"]).notNull(),
  location: text("location").notNull(), // عنوان الموقع
  latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
  longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["pending", "assigned", "in_progress", "resolved", "closed"]).default("pending").notNull(),
  severity: mysqlEnum("severity", ["low", "medium", "high", "critical"]).default("medium").notNull(),
  reportedAt: timestamp("reportedAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Incident = typeof incidents.$inferSelect;
export type InsertIncident = typeof incidents.$inferInsert;

// جدول الأطراف المتورطة في الحادث
export const incidentParties = mysqlTable("incidentParties", {
  id: int("id").autoincrement().primaryKey(),
  incidentId: int("incidentId").notNull(),
  partyName: varchar("partyName", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  vehicleNumber: varchar("vehicleNumber", { length: 50 }),
  faultPercentage: int("faultPercentage").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type IncidentParty = typeof incidentParties.$inferSelect;
export type InsertIncidentParty = typeof incidentParties.$inferInsert;

// جدول الخدمات المطلوبة
export const services = mysqlTable("services", {
  id: int("id").autoincrement().primaryKey(),
  incidentId: int("incidentId").notNull(),
  serviceType: mysqlEnum("serviceType", ["ambulance", "tow_truck", "traffic_control", "police", "fire"]).notNull(),
  status: mysqlEnum("status", ["pending", "assigned", "en_route", "arrived", "completed", "cancelled"]).default("pending").notNull(),
  assignedTo: varchar("assignedTo", { length: 255 }),
  estimatedArrivalTime: timestamp("estimatedArrivalTime"),
  arrivedAt: timestamp("arrivedAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Service = typeof services.$inferSelect;
export type InsertService = typeof services.$inferInsert;

// جدول الصور والفيديوهات المحاكاة
export const incidentMedia = mysqlTable("incidentMedia", {
  id: int("id").autoincrement().primaryKey(),
  incidentId: int("incidentId").notNull(),
  mediaType: mysqlEnum("mediaType", ["image", "video"]).notNull(),
  mediaUrl: text("mediaUrl").notNull(),
  description: text("description"),
  isSimulated: boolean("isSimulated").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type IncidentMedia = typeof incidentMedia.$inferSelect;
export type InsertIncidentMedia = typeof incidentMedia.$inferInsert;

// جدول السجل التاريخي للحوادث
export const incidentHistory = mysqlTable("incidentHistory", {
  id: int("id").autoincrement().primaryKey(),
  incidentId: int("incidentId").notNull(),
  action: varchar("action", { length: 255 }).notNull(),
  details: text("details"),
  performedBy: int("performedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type IncidentHistory = typeof incidentHistory.$inferSelect;
export type InsertIncidentHistory = typeof incidentHistory.$inferInsert;

// جدول الإحصائيات
export const statistics = mysqlTable("statistics", {
  id: int("id").autoincrement().primaryKey(),
  date: timestamp("date").defaultNow().notNull(),
  totalIncidents: int("totalIncidents").default(0),
  injuryIncidents: int("injuryIncidents").default(0),
  breakdownIncidents: int("breakdownIncidents").default(0),
  trafficIncidents: int("trafficIncidents").default(0),
  averageResolutionTime: int("averageResolutionTime").default(0), // بالدقائق
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Statistic = typeof statistics.$inferSelect;
export type InsertStatistic = typeof statistics.$inferInsert;

// جدول تتبع إرسالات التقارير
export const reportSends = mysqlTable("reportSends", {
  id: int("id").autoincrement().primaryKey(),
  incidentId: int("incidentId").notNull(),
  recipientType: mysqlEnum("recipientType", ["party", "insurance", "najm", "operator"]).notNull(),
  recipientEmail: varchar("recipientEmail", { length: 255 }).notNull(),
  recipientPhone: varchar("recipientPhone", { length: 20 }),
  recipientName: varchar("recipientName", { length: 255 }),
  status: mysqlEnum("status", ["pending", "sent", "failed", "read"]).default("pending").notNull(),
  sentAt: timestamp("sentAt"),
  readAt: timestamp("readAt"),
  failureReason: text("failureReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ReportSend = typeof reportSends.$inferSelect;
export type InsertReportSend = typeof reportSends.$inferInsert;
